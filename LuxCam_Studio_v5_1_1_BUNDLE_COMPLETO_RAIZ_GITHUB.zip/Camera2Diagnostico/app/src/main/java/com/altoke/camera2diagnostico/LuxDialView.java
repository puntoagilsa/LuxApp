package com.altoke.camera2diagnostico;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Lightweight responsive circular control. Camera2 validation remains in the activity. */
public final class LuxDialView extends View {
    public interface Listener { void onChoose(int index); }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int selection;
    private String title = "ISO";
    private String[] labels = {"AUTO", "100", "200", "400", "800", "1600"};
    private Listener listener;
    public LuxDialView(Context c, AttributeSet a) { super(c, a); setContentDescription("Control manual"); }
    public void configure(String name, String[] options, Listener callback) {
        title = name; labels = options.clone(); listener = callback;
        setContentDescription(name + ": " + labels[selection]); invalidate();
    }
    public void setSelection(int position) {
        selection = Math.max(0, Math.min(labels.length - 1, position));
        setContentDescription(title + ": " + labels[selection]); invalidate();
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * .41f;
        float r = Math.min(w * .43f, h * .32f);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(0xFF303844);
        c.drawCircle(cx, cy, r, p);
        for (int i = 0; i <= 20; i++) {
            double a = Math.toRadians(140 + i * 13f);
            float ri = r - (i % 5 == 0 ? 9f : 4f);
            p.setColor(i <= selection * 20f / Math.max(1, labels.length - 1) ? 0xFFE5B76A : 0xFF626872);
            p.setStrokeWidth(i % 5 == 0 ? 2.1f : 1f);
            c.drawLine(cx+(float)Math.cos(a)*ri,cy+(float)Math.sin(a)*ri,
                    cx+(float)Math.cos(a)*r,cy+(float)Math.sin(a)*r,p);
        }
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF191E25); c.drawCircle(cx,cy,r*.71f,p);
        p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.WHITE); p.setTextSize(10f * getResources().getDisplayMetrics().scaledDensity);
        c.drawText(labels[selection],cx,cy+3,p);
        p.setColor(0xFFE7BD78); p.setTextSize(9f*getResources().getDisplayMetrics().scaledDensity);
        c.drawText(title,cx,h-3f*getResources().getDisplayMetrics().density,p);
    }
    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (!isEnabled() || labels.length == 0) return false;
        if (ev.getAction() == MotionEvent.ACTION_UP) {
            // One tap advances the wheel. Swipe up/down chooses direction.
            int next = (selection + (ev.getY() < getHeight()*.35f ? -1 : 1) + labels.length) % labels.length;
            if (listener != null) listener.onChoose(next);
            performClick(); return true;
        }
        return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }
}
