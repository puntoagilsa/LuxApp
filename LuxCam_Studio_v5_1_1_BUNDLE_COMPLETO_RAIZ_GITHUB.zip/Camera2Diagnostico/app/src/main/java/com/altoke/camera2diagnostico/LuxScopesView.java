package com.altoke.camera2diagnostico;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/** RGB + luminance histogram of PREVIEW pixels. Not a RAW waveform or final-JPEG guarantee. */
public final class LuxScopesView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[][] bins = new int[4][64];
    private float audioLevel = 0;
    private boolean audioActive;
    public LuxScopesView(Context c, AttributeSet a) { super(c,a); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
    public void setPreviewSample(Bitmap bmp) {
        if (bmp == null) return;
        for (int[] b : bins) java.util.Arrays.fill(b,0);
        int width=bmp.getWidth(), height=bmp.getHeight();
        for (int y=0; y<height; y+=3) for (int x=0; x<width; x+=3) {
            int pixel=bmp.getPixel(x,y);
            int r=Color.red(pixel),g=Color.green(pixel),b=Color.blue(pixel);
            bins[0][Math.min(63,(int)((.2126*r+.7152*g+.0722*b)/4))]++;
            bins[1][r>>2]++; bins[2][g>>2]++; bins[3][b>>2]++;
        }
        invalidate();
    }
    public void setAudioMeter(int amplitude, boolean active) {
        audioActive=active;
        float a=active ? Math.max(0,Math.min(1f,amplitude/32767f)) : 0;
        audioLevel=.65f*audioLevel+.35f*a;
        invalidate();
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        p.setStyle(Paint.Style.FILL); p.setColor(0xE50C1016);
        c.drawRoundRect(0,0,getWidth(),getHeight(),9,9,p);
        float left=8,top=17,right=getWidth()-23,bottom=getHeight()-11;
        p.setStrokeWidth(1); p.setColor(0xFF464A50);
        for (int i=1;i<4;i++) c.drawLine(left,top+(bottom-top)*i/4,right,top+(bottom-top)*i/4,p);
        int[] colors={0xFFF3F4F5,0x99EF6560,0x9980D78B,0x9973A7E2};
        for(int band=3;band>=0;band--) {
            int max=1;
            for(int v:bins[band]) max=Math.max(max,v);
            Path path=new Path(); path.moveTo(left,bottom);
            for(int i=0;i<64;i++) {
                float x=left+(right-left)*i/63f;
                // compress peaked histogram without hiding distribution
                float ht=(float)Math.sqrt((double)bins[band][i]/max);
                path.lineTo(x,bottom-(bottom-top)*ht);
            }
            p.setColor(colors[band]); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(band==0?1.5f:1f);
            c.drawPath(path,p);
        }
        p.setColor(0xFFE5B76A);p.setStyle(Paint.Style.FILL);
        float mx=getWidth()-13, meterBottom=getHeight()-13;
        c.drawRect(mx-3,meterBottom-audioLevel*(bottom-top),mx+3,meterBottom,p);
        p.setColor(0xFFEDEDED); p.setTextSize(10f*getResources().getDisplayMetrics().scaledDensity);
        c.drawText("HIST RGB",8,12,p);
        p.setTextSize(8f*getResources().getDisplayMetrics().scaledDensity);
        c.drawText(audioActive?"MIC":"--",getWidth()-25,12,p);
    }
}
