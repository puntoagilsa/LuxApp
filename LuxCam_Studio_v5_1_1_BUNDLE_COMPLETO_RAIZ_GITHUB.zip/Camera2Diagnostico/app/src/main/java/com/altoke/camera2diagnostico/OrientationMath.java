package com.altoke.camera2diagnostico;

/** Deterministic 90-degree camera orientation utilities. Pure Java: testable without Android SDK. */
public final class OrientationMath {
    private OrientationMath() { }
    public static int rotationDegrees(int surfaceRotation) {
        switch (surfaceRotation) {
            case 1: return 90;
            case 2: return 180;
            case 3: return 270;
            default: return 0;
        }
    }
    private static int wrap(int degrees) { return (degrees % 360 + 360) % 360; }
    /** Source: Android Camera2 JPEG orientation guidance for display rotation. */
    public static int jpegFromDisplay(int sensor, int display, boolean front) {
        return wrap(sensor + (front ? display : -display));
    }
    /** OrientationEventListener reports physically clockwise degrees, not Surface rotation. */
    public static int jpegFromClockwiseSensor(int sensor, int physical, boolean front) {
        return wrap(sensor + (front ? -physical : physical));
    }
    /** Preview texture buffer rotation; preview mirroring is a separate presentation decision. */
    public static int previewRotation(int sensor, int display, boolean front) {
        return wrap(sensor + (front ? display : -display));
    }
}
