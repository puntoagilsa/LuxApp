package com.altoke.camera2diagnostico;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Display-only metering reticle. Does not intercept taps on TextureView. */
public final class LuxFocusView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float px = -1, py = -1;
    private long touched;
    public LuxFocusView(Context c, AttributeSet a) { super(c, a); setWillNotDraw(false); }
    public void highlight(float x, float y) { px=x; py=y; touched=android.os.SystemClock.uptimeMillis(); invalidate(); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (px < 0 || android.os.SystemClock.uptimeMillis()-touched>1700) return;
        p.setColor(0xFFE9BE76); p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f*getResources().getDisplayMetrics().density);
        float side=58f*getResources().getDisplayMetrics().density;
        c.drawRoundRect(new RectF(px-side/2,py-side/2,px+side/2,py+side/2),4,4,p);
        c.drawCircle(px,py,3f*getResources().getDisplayMetrics().density,p);
        postInvalidateDelayed(1800);
    }
}
