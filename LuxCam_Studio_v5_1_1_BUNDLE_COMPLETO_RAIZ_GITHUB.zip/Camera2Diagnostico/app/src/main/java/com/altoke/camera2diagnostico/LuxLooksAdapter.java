package com.altoke.camera2diagnostico;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

/** Presets: only NATURAL and REC 709 are backed by the existing Camera2 renderer. */
public final class LuxLooksAdapter extends RecyclerView.Adapter<LuxLooksAdapter.Cell> {
    public interface Choice { void select(int position); }
    private static final String[] NAMES={"NATURAL","REC 709","LOG C","BLEACH","MONO","VINTAGE"};
    private static final int[] BG={0xFF434B50,0xFF49413B,0xFF333436,0xFF74695A,0xFF565656,0xFF574135};
    private final Choice onChoose;
    private int selected;
    public LuxLooksAdapter(Choice c){onChoose=c;}
    public void select(int i){selected=i;notifyDataSetChanged();}
    @Override public Cell onCreateViewHolder(ViewGroup parent,int viewType){
        Context c=parent.getContext();
        LinearLayout layout=new LinearLayout(c); layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        RecyclerView.LayoutParams rp=new RecyclerView.LayoutParams(dp(c,77),dp(c,92));
        rp.rightMargin=dp(c,7);layout.setLayoutParams(rp);
        TextView sample=new TextView(c); sample.setGravity(Gravity.CENTER);
        sample.setTextColor(Color.WHITE);sample.setTextSize(10);
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        layout.addView(sample,new LinearLayout.LayoutParams(dp(c,72),dp(c,67)));
        TextView label=new TextView(c);label.setTextSize(9);label.setGravity(Gravity.CENTER);
        layout.addView(label,new LinearLayout.LayoutParams(-1,dp(c,22)));
        return new Cell(layout,sample,label);
    }
    @Override public void onBindViewHolder(Cell holder,int pos){
        boolean supported=pos<2;boolean active=pos==selected;
        GradientDrawable b=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{BG[pos],0xFF101217});b.setCornerRadius(dp(holder.itemView.getContext(),7));
        b.setStroke(dp(holder.itemView.getContext(),active?2:1),active?0xFFE5B76A:0xFF484848);
        holder.sample.setBackground(b);holder.sample.setText(NAMES[pos]);
        holder.sample.setAlpha(supported?1f:.42f);
        holder.label.setText(supported?(active?"ACTIVO":"LOOK"):"NO DISP.");
        holder.label.setTextColor(active?0xFFE5B76A:0xFFB3BAC1);
        holder.itemView.setOnClickListener(v->onChoose.select(pos));
        holder.itemView.setContentDescription(NAMES[pos]+(supported?"":" no disponible"));
    }
    @Override public int getItemCount(){return NAMES.length;}
    private static int dp(Context c,int d){return Math.round(d*c.getResources().getDisplayMetrics().density);}
    static final class Cell extends RecyclerView.ViewHolder {
        final TextView sample,label;
        Cell(View v,TextView s,TextView l){super(v);sample=s;label=l;}
    }
}
