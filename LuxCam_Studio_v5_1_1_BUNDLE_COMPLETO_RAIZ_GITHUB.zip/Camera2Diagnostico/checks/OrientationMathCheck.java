package com.altoke.camera2diagnostico;

public final class OrientationMathCheck {
    private static void check(int expect, int actual, String description) {
        if (expect != actual) throw new AssertionError(description + ": expected=" + expect + " actual=" + actual);
    }
    public static void main(String[] args) {
        for (int rotation = 0; rotation <= 3; rotation++)
            check(rotation*90, OrientationMath.rotationDegrees(rotation), "Surface rotation " + rotation);
        // Common sensor orientations: rear = 90, front = 270.
        check(90, OrientationMath.jpegFromDisplay(90, 0, false), "rear portrait");
        check(0, OrientationMath.jpegFromDisplay(90, 90, false), "rear landscape-right");
        check(180, OrientationMath.jpegFromDisplay(90, 270, false), "rear landscape-left");
        check(270, OrientationMath.jpegFromDisplay(270, 0, true), "front portrait");
        check(0, OrientationMath.jpegFromDisplay(270, 90, true), "front landscape-right");
        check(180, OrientationMath.jpegFromDisplay(270, 270, true), "front landscape-left");
        check(90, OrientationMath.previewRotation(90,0,false), "rear preview portrait");
        check(270, OrientationMath.previewRotation(270,0,true), "front preview portrait");
        check(0, OrientationMath.previewRotation(90,90,false), "rear preview landscape-right");
        check(180, OrientationMath.previewRotation(90,270,false), "rear preview landscape-left");
        check(0, OrientationMath.previewRotation(270,90,true), "front preview landscape-right");
        check(0, OrientationMath.jpegFromClockwiseSensor(90,270,false), "rear clockwise physical 270");
        check(0, OrientationMath.jpegFromClockwiseSensor(270,270,true), "front clockwise physical 270");
        System.out.println("OrientationMath: 17 assertions OK (pure Java; not a device validation)");
    }
}
