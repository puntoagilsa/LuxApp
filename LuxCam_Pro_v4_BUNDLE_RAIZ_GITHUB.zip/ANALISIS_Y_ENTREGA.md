# LuxCam Pro 4.0 — Release candidate verificable

Fecha: 2026-10-15. Base: código fuente LuxCam Pro v3 disponible en esta conversación. **No fue posible acceder a la versión live del repositorio GitHub ni ejecutar Android/Gradle localmente.**

## Análisis de archivos compartidos

- `lux.jpg` 960×1280, sin etiqueta EXIF orientación en la copia compartida; la escena se observa girada. `camara.jpg` 1280×960, escena horizontal correcta. Esto fundamenta corregir el comportamiento al girar el teléfono; **no permite determinar la etiqueta EXIF del JPEG original del teléfono**, porque una aplicación intermediaria puede eliminarla.
- En `lux.jpg`, luminancia BT.709 reducida a 320×320: ~12,2 % de píxeles con Y<30 y ~4,4 % con Y>245. En `camara.jpg`: ~7,4 % y ~1,6 %. **Las escenas no son idénticas; son estadísticas descriptivas, no una evaluación de HDR.**
- `lux.mp4`: AVC 720×1280, promedio ~29,7 cuadros/s, audio AAC mono 48 kHz a 192 kb/s. `original.mp4`: AVC 1280×720, promedio ~60 cuadros/s, AAC estéreo 48 kHz a 256 kb/s. Son **copias compartidas** y no prueban el bitrate ni resolución del archivo MP4 de origen almacenado en el teléfono.
- La capacidad `RAW_SENSOR` no está expuesta por la cámara trasera ni la frontal. No se ofrece DNG. EIS/OIS tampoco anunciados. Diagnóstico proporcionado: `Camera2_Infinix X678B_fase1 (1).txt`.

## Cambios incorporados al código (necesitan compilarse y probarse)

1. **Orientación**: actividad admite rotación completa, `onConfigurationChanged`, orientaciones basadas en `SENSOR_ORIENTATION` y `Display.getRotation`, apoyo de `OrientationEventListener` para situaciones con pantalla aún vertical; cálculo separado para JPEG, video MP4 y visor; fijación de orientación de la interfaz durante la grabación (la rotación en MP4 no puede modificarse a mitad de un archivo). Frontal con previsualización espejo únicamente.
2. **Foto**: mayor JPEG 4:3 anunciado, calidad de compresión solicitada 100, CaptureIntent STILL, corrección tonal HDR no ficticia (Camera2 HIGH_QUALITY donde exista), reducción de ruido y aberración óptica en calidad foto. Almacenamiento existente fuera del hilo de cámara, MediaStore pending -> publish y miniatura cuando termina.
3. **Video**: H.264 1080p/30 nominal, opción experimental de 1440p si MediaRecorder anuncia ese tamaño; 20 y 35 Mbps solicitados. Anti-banding AUTO o 60 Hz como alternativa. TONEMAP HQ donde esté disponible y modo REC709 donde esté anunciado. Reducción de ruido FAST en video por estabilidad. Manual shutter 1/60 a 30 fps (regla de 180º); ISO manual disponible también en video si sensor lo anuncia.
4. **Controles**: panel PRO (ISO, shutter, WB aproximado Kelvin basado en ganancias Camera2, exposición AE y AF lock, zoom, color Natural o Cine709, flash foto trasera), interfaz oscura, cuadrícula.
5. **Audio**: opción CAMCORDER (ambiente) o VOICE_COMMUNICATION (voz, procesamiento opcional de la HAL); AAC mono 48 kHz/192 kbps solicitado. **No se implementó aplicación explícita de AudioEffects**: requiere AudioRecord con ID de sesión de audio y codificación/multiplexación alternativa; no sería correcto afirmar que `NoiseSuppressor`/`AutomaticGainControl` se aplicaron desde MediaRecorder.

## Funcionalidades expresamente NO incluidas

- LUT 3D OpenGL procesado en el **mismo flujo de vista previa y video codificado**. Un filtro en TextureView no modifica la salida de MediaRecorder. Requiere cámara -> OES texture -> FBO/shader -> Surface encoder con EGL timestamps y muxer, y una fuente AudioRecord sincronizada. Implementarlo sin pruebas de rendimiento real puede causar pérdida de fotogramas.
- HDR multiframe con alineación, IA local para ruido, recuperación de datos no capturados, RAW/DNG (HAL no lo anuncia), 4K y 60 fps. Se tratarán solo tras pruebas de hardware y datos de latencia.
- Estabilización EIS/OIS no anunciada por el HAL. No afirmar compatibilidad.
- Validación de fotografías directamente obtenidas de la nueva APK. **Esta entrega es candidata, no definitiva validada**.

## Cómo compilar sin Android Studio (método habitual)

Se recomienda conservar el repositorio `puntoagilsa/LuxApp`, rama `main`, carpeta de proyecto `Camera2Diagnostico`.

1. Descargar `LuxCam_Pro_v4_BUNDLE_RAIZ_GITHUB.zip` de ChatGPT.
2. En GitHub > Code, **subir ese ZIP sin descomprimir a la raíz del repositorio** (junto a `Camera2Diagnostico`, no dentro).
3. Editar `.github/workflows/compilar-apk.yml` y pegar el workflow íntegro incluido en `WORKFLOW_NUEVO.yml` (abajo en las descargas).
4. Hacer Commit. El workflow descomprime la actualización por encima de `Camera2Diagnostico` en el runner (no modifica permanentemente los archivos del repositorio) y compila usando Gradle 8.9 / Android SDK 34.
5. En Actions, cuando la ejecución esté verde, descargar el artefacto `LuxCam-Pro-v4-APK` y extraer `app-debug.apk`.
6. Si falla, abrir job `compilar`, copiar los últimos 30 renglones del **primer paso rojo**, no del resumen general. No considerar compilado si no aparece artefacto.

La actualización por ZIP como paso CI hace el código de la versión 4 **menos visible en el historial Git del repositorio**. Para un mantenimiento profesional posterior conviene subir los archivos descomprimidos y versionados (sin el paso unzip); el ZIP es aquí el método de menor complejidad dadas las instrucciones previas.

## Plan de validación real de dispositivo

- **Orientación** (4 combinaciones): trasera/frontal, vertical/apaisado, comprobar vista previa, JPEG en Galería *y* bytes/EXIF, MP4 y matriz de rotación en `ffprobe`.
- **Captura**: asegurar que la app confirma `Guardado` únicamente al publicar el URI. Abrir miniatura. Probar secuencia de cinco fotos y video de 10 s, luego video de 2 minutos. Medir segundos hasta miniatura.
- **Exposición**: escenas idénticas con trípode o apoyo; luces altas de tienda, ropa blanca, rostro, oscuro interior. Comparar histograma y textura en sombras con EV -0,3 y 0. No prometer recuperación si píxeles saturados.
- **Video**: verificar resolución/fps/bitrate *en el archivo original*; 1080p/30 antes de 1440p/30; bloquear ISO/shutter y verificar que no produce flicker ni exposición incorrecta.
- **Audio**: CAMCORDER frente a VOICE_COMMUNICATION con ventilador y voz; comparar clipping, articulación, ruido estacionario, eco y bitrate. Si modo VOZ degrada, regresar AMBIENTE.
- **Regresión**: permiso denegado, cambio de cámaras y modo, dejar app en segundo plano durante grabación, memoria casi llena, rotar justo antes/durante grabación.

## Decisiones técnicas

- `OrientationMath.java` no usa Android; se ejecutaron 14 comprobaciones de valores representativos con `javac` y `java` local. Esto solo comprueba matemáticas, **no** la orientación final renderizada por el HAL.
- Gradle 8.9 + Android plugin 8.7.3, Java 17, Android API 34, configuración probada previamente en GitHub para v3, todavía no comprobada para v4.
- Se aprovechan colores Natural (Camera2 HIGH_QUALITY) y Cine 709 (Camera2 PRESET_CURVE_REC709) solo si la cámara los anuncia; esto **no es LUT OpenGL**.
- Los ajustes Kelvin expresan niveles aproximados y no un sensor colorímetro; pueden variar entre cámaras.
