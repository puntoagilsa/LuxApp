# LuxCam Pro 5.2 — prueba de looks ISP, enfoque táctil y calidad

Estado: **código preparado, pendiente de compilación GitHub Actions y pruebas físicas**.

## Instalación

Identificador distinto: `com.altoke.luxcampro.beta52`. Se instala junto a LuxCam 5.1.3.
Android: API 29+; probado por el usuario previamente en X678B Android 14 con las versiones 5.1.x, pero esta 5.2 NO está probada.

## Cambios frente a 5.1.3

- Ocho ajustes de color: NATURAL, REC709, CINE SUAVE, FILM CÁLIDO, FILM FRÍO, FILM FADE, CONTRASTE, MONO.
- NATURAL conserva el tonemapping nativo; REC709 requiere preset de Camera2.
- Cinco looks intermedios usan **curvas RGB 1D con TONEMAP_MODE_CONTRAST_CURVE** en la HAL, si se anuncia.
- MONO requiere CONTROL_EFFECT_MODE_MONO.
- Cada look solo aparece activo si Camera2 anuncia el modo correspondiente. `CaptureResult` verifica el modo reportado; no garantiza fidelidad cromática.
- Las curvas se solicitan tanto en vista previa como captura JPEG y grabación MP4: no hay filtro solo visual.
- En la cámara trasera, tocar un sujeto envía un disparo AF_AUTO, fija medición local y vuelve a AF continuo tras 2.3 s.
- Mantiene el guardado asíncrono y la miniatura solo al publicar en MediaStore.
- Foto JPEG solicitada a calidad 100, video H264 1080p30 ~20 Mb/s y AAC mono 48 kHz.

## Limitaciones reales

- **Estos no son LUTs 3D OpenGL ni una simulación idéntica a ARRI LOG C**. Son curvas tonales RGB 1D (o efectos nativos MONO/REC709). La HAL podría no respetarlos plenamente, aun anunciándolos. Verificar con fotos y MP4 del dispositivo.
- No se incluye HDR multicuadro, IA de mejora local, estabilización EIS/OIS o RAW/DNG: no han sido validados.
- No se ha ejecutado compilación Android en el entorno actual. Si falla GitHub enviar el log completo del primer paso rojo.
- No recomendamos reemplazar tu cámara nativa para encargos profesionales hasta validar enfoque, fotos, orientación y video continuado (5 minutos).

## Parámetros recomendados para trabajar HOY

- PERSONAS: AUTO, NATURAL, fotografía, 1×, tocar el rostro y esperar un instante antes de capturar; luz natural lateral sin contraluz fuerte.
- EXTERIOR brillante: PROTEGER LUCES ON si el cielo se quema; desactivar si deja a la persona demasiado oscura.
- VIDEO: 1080p 30 FPS / H.264, enfoque continuo y AE automático, 1×, evitar saltos de zoom. Probar clips de 5-10 s y comprobar audio y orientación en Galería.
- LOOK CINE SUAVE: para color moderado si la HAL realmente confirma la curva; para entrega profesional conservar una toma NATURAL adicional.
- MANUAL: obturación 1/60 s a 30 FPS solo si también ajustas ISO de acuerdo con la luz; no existe ISO AUTO real con shutter fijo en esta implementación.

## Comprobar las fotografías originales

En Galería/Archivos revisar resolución del JPEG guardado. Android Camera2 en X678B anunció ~3968x2976 trasera; las fotos compartidas aquí son 2048x1536 y pueden haber sido reducidas al transferir. No confundir resolución del archivo recibido con la máxima capturada.

## Rutas de código

- `Camera2Diagnostico/app/src/main/java/com/altoke/camera2diagnostico/LuxCamActivity.java`
- `Camera2Diagnostico/app/src/main/java/com/altoke/camera2diagnostico/LuxLooksAdapter.java`
- `Camera2Diagnostico/app/src/main/java/com/altoke/camera2diagnostico/LuxToneCurves.java`
- `Camera2Diagnostico/checks/LuxToneCurvesCheck.java`
- `Camera2Diagnostico/app/build.gradle`
- `Camera2Diagnostico/app/src/main/AndroidManifest.xml`

No subir claves de firma ni cuentas a GitHub. APK de depuración para pruebas, no distribución final.
