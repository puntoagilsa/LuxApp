package com.altoke.camera2diagnostico;

/**
 * Small, monotonic 1D RGB tone lookup tables (LUTs) for Camera2 TONEMAP_CURVE.
 * These are not 3D LUTs and must not be presented as ARRI Log C.
 * The Camera HAL may decline or ignore custom tonemapping, so query supported
 * modes before using this class and validate with a device capture.
 */
public final class LuxToneCurves {
    private static final int POINTS = 32;
    private LuxToneCurves() {}

    /** @param look 2 soft cine, 3 warm, 4 cool, 5 faded, 6 contrast */
    public static float[][] forLook(int look) {
        if (look < 2 || look > 6) throw new IllegalArgumentException("invalid look " + look);
        float[][] c = new float[3][];
        for (int ch = 0; ch < 3; ch++) {
            float[] pairs = new float[POINTS * 2];
            for (int i = 0; i < POINTS; i++) {
                float x = i / (float)(POINTS - 1);
                float y;
                switch (look) {
                    case 2: // Cinematic soft: softer highlights, slightly open blacks.
                        y = 0.013f + 0.967f * (float)Math.pow(x, 0.99);
                        break;
                    case 3: // Warm: small natural channel shifts.
                        y = (ch == 0 ? 0.011f : ch == 2 ? 0.006f : 0.009f)
                            + (ch == 0 ? 0.987f : ch == 2 ? 0.963f : 0.979f)
                            * (float)Math.pow(x, ch == 0 ? 0.965 : ch == 2 ? 1.045 : 1.0);
                        break;
                    case 4: // Cool neutral cinema.
                        y = (ch == 2 ? 0.011f : 0.006f)
                            + (ch == 2 ? 0.984f : ch == 0 ? 0.959f : 0.979f)
                            * (float)Math.pow(x, ch == 2 ? 0.968 : ch == 0 ? 1.047 : 1.0);
                        break;
                    case 5: // Flat/fade, but NOT log gamma or HDR.
                        y = 0.036f + 0.919f * x;
                        break;
                    default: // Controlled contrast, keeps a monotonic mapping.
                        y = x + 0.32f*x*(1f-x)*(2f*x-1f);
                }
                pairs[i*2] = x;
                pairs[i*2+1] = Math.max(0f, Math.min(1f, y));
            }
            c[ch] = pairs;
        }
        return c;
    }
}
