package com.altoke.camera2diagnostico;

import android.Manifest;
import android.app.Activity;
import android.content.res.Configuration;
import android.view.OrientationEventListener;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.params.RggbChannelVector;
import android.hardware.camera2.params.ColorSpaceTransform;
import android.media.audiofx.NoiseSuppressor;
import android.media.audiofx.AutomaticGainControl;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.CamcorderProfile;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Rational;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * LuxCam Pro 4.0 RC: prueba funcional de fotografia JPEG y video AVC 1080p.
 * Sin librerias externas. La correccion de exposicion funciona desde Camera2,
 * no modifica ni recompone artificialmente pixeles capturados.
 * Las salidas de la camara se deben validar en el Infinix X678B.
 */
public final class LuxCamActivity extends Activity {
    private static final int CAMERA_PERMISSION = 101;
    private static final int MICROPHONE_PERMISSION = 102;
    private static final int WHITE = Color.rgb(246, 249, 252);
    private static final int ACCENT = Color.rgb(227, 185, 108);
    private static final int PANEL = Color.rgb(13, 19, 29);
    private static final String PICTURES_FOLDER = "Pictures/LuxCam";
    private static final String VIDEOS_FOLDER = "Movies/LuxCam";
    private OrientationEventListener physicalOrientationListener;
    private int physicalOrientation = OrientationEventListener.ORIENTATION_UNKNOWN;
    private int recordingOrientationHint;
    private LinearLayout bottomControls;
    private Button lookButton, afLockButton, qualityButton, audioButton, shutter180Button;
    private boolean afLocked;
    private boolean tapFocusActive;
    private int focusRequestSerial;
    private int lookIndex, qualityIndex, audioIndex;
    private volatile int verifiedLookIndex = -1;
    private static final String[] LOOKS = {"NATURAL", "REC709", "CINE SUAVE", "FILM CÁLIDO", "FILM FRÍO", "FILM FADE", "CONTRASTE", "MONO"};
    private static final String[] WB_LABELS_K = {"AUTO", "3200K~", "4500K~", "5600K~", "6500K~"};
    private static final int[] WB_KELVIN = {0, 3200, 4500, 5600, 6500};
    private volatile RggbChannelVector lastAutoGains;
    private volatile ColorSpaceTransform lastAutoTransform;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Semaphore cameraLock = new Semaphore(1);
    private final ExecutorService saveExecutor = Executors.newSingleThreadExecutor();
    private ImageView lastThumbnail;
    private TextView savedHint;
    private volatile Uri latestSavedUri;
    private volatile String latestSavedMime;
    private volatile boolean finalizingVideo;
    private Button proButton;
    private LinearLayout proPanel;
    private View advancedContainer;
    private Button isoButton, speedButton, wbButton, flashButton, zoomButton, aeLockButton;
    private boolean proExpanded, flashAuto, aeLocked;
    private int isoIndex, speedIndex, wbIndex, zoomIndex;
    private static final int[] ISO_CHOICES = {0, 100, 200, 400, 800, 1600};
    private static final long[] SPEED_CHOICES = {0L, 33333333L, 16666667L, 8333333L, 4000000L, 2000000L};
    private static final String[] SPEED_LABELS = {"AUTO", "1/30", "1/60", "1/120", "1/250", "1/500"};
    
    private android.util.Range<Integer> isoRange;
    private android.util.Range<Long> shutterRange;
    private boolean manualSensor;
    private float maxDigitalZoom = 1f;
    private Rect cropRegion;
    private final AtomicBoolean openingCamera = new AtomicBoolean(false);
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private TextureView textureView;
    private GridView gridView;
    private TextView statusText;
    private TextView evLabel;
    private TextView headingSub;
    private LuxFocusView focusOverlay;
    private LuxScopesView scopes;
    private LuxDialView shutterDial, isoDial;
    private LuxLooksAdapter looksAdapter;
    private TextView metaText, batteryLabel, rawLabel, recordTag;
    private Button manualToggle, wbQuickButton;

    private TextView timerText;
    private TextView resolutionLabel;
    private Button photoModeButton;
    private Button videoModeButton;
    private Button shutterButton;
    private Button protectButton;
    private Button cameraButton;
    private Button gridButton;
    private SeekBar evBar;

    private CameraDevice device;
    private CameraCaptureSession captureSession;
    private CaptureRequest.Builder repeatingBuilder;
    private ImageReader jpegReader;
    private Surface previewSurface;
    private CameraCharacteristics characteristics;
    private Size previewSize;
    private Size videoSize = new Size(1920, 1080);
    private String cameraId;
    private String backId;
    private String frontId;
    private int cameraFacing = CameraCharacteristics.LENS_FACING_BACK;
    private int sensorOrientation = 90;
    private boolean sessionReady;
    private boolean recording;
    private boolean startingRecording;
    private boolean takingPhoto;
    private boolean videoMode;
    private boolean highlightGuard;
    private float manualEv;
    private boolean paused;
    private int generation;
    private long recordStartMs;
    private Range<Integer> evRange = new Range<>(-20, 20);
    private float evStep = .1f;
    private int maxAfRegions;
    private int maxAeRegions;
    private Rect activeArray;
    private MeteringRectangle[] afRegions;
    private MeteringRectangle[] aeRegions;
    private MediaRecorder recorder;
    private ParcelFileDescriptor videoFd;
    private Uri videoUri;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        physicalOrientationListener = new OrientationEventListener(this) {
            @Override public void onOrientationChanged(int degrees) {
                if (degrees != ORIENTATION_UNKNOWN) physicalOrientation = ((degrees + 45) / 90 * 90) % 360;
            }
        };
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(PANEL);
        getWindow().setNavigationBarColor(PANEL);
        applyImmersiveUi();
        buildInterface();
    }

    @Override protected void onResume() {
        super.onResume();
        paused = false;
        applyImmersiveUi();
        if (physicalOrientationListener != null && physicalOrientationListener.canDetectOrientation()) physicalOrientationListener.enable();
        cameraThread = new HandlerThread("LuxCamCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        main.removeCallbacks(scopesTick);
        main.postDelayed(scopesTick, 800);
        if (textureView.isAvailable()) requestOrOpenCamera();
        else textureView.setSurfaceTextureListener(surfaceListener);
    }

    @Override protected void onDestroy() {
        main.removeCallbacks(scopesTick);
        saveExecutor.shutdown(); // Se terminan los guardados ya encolados.
        if (physicalOrientationListener != null) physicalOrientationListener.disable();
        super.onDestroy();
    }

    @Override protected void onPause() {
        paused = true;
        if (physicalOrientationListener != null) physicalOrientationListener.disable();
        generation++;
        main.removeCallbacks(scopesTick);
        if (recording || startingRecording) stopRecording(false);
        closeCamera();
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(1200); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            cameraThread = null;
            cameraHandler = null;
        }
        super.onPause();
    }

    private void applyImmersiveUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private int dp(float n) { return Math.round(getResources().getDisplayMetrics().density * n); }

    private GradientDrawable background(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private Button action(String text, int background, int foreground, int radius) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(foreground);
        b.setTextSize(13);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setBackground(background(background, radius, Color.TRANSPARENT));
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setMinimumHeight(0); b.setMinHeight(0);
        b.setMinimumWidth(0); b.setMinWidth(0);
        return b;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private LinearLayout horizontal() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private LinearLayout.LayoutParams rowWeight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    /** XML-backed, compact studio UI. The Camera2 engine remains independent of widgets. */
    private void buildInterface() {
        setContentView(R.layout.activity_luxcam_studio);
        FrameLayout root = findViewById(R.id.studio_root);
        FrameLayout previewBox = findViewById(R.id.preview_container);
        textureView = findViewById(R.id.camera_preview);
        focusOverlay = findViewById(R.id.focus_overlay);
        scopes = findViewById(R.id.studio_scopes);
        statusText = findViewById(R.id.studio_status);
        savedHint = findViewById(R.id.saved_state);
        timerText = findViewById(R.id.studio_timer);
        evLabel = findViewById(R.id.ev_value);
        evBar = findViewById(R.id.exposure_slider);
        protectButton = findViewById(R.id.protect_button);
        photoModeButton = findViewById(R.id.photo_mode);
        videoModeButton = findViewById(R.id.video_mode);
        shutterButton = findViewById(R.id.shutter);
        lastThumbnail = findViewById(R.id.recent_thumbnail);
        bottomControls = findViewById(R.id.bottom_studio);
        proPanel = findViewById(R.id.studio_advanced);
        advancedContainer = findViewById(R.id.studio_advanced_scroll);
        resolutionLabel = findViewById(R.id.studio_quality);
        rawLabel = findViewById(R.id.raw_label);
        batteryLabel = findViewById(R.id.battery_label);
        recordTag = findViewById(R.id.record_tag);
        metaText = findViewById(R.id.studio_meta);
        manualToggle = findViewById(R.id.studio_auto_manual);
        shutterDial = findViewById(R.id.shutter_dial);
        isoDial = findViewById(R.id.iso_dial);
        looksAdapter = new LuxLooksAdapter(position -> {
            if (!isLookAvailable(position)) {
                show("Este preset no está anunciado por la cámara actual");
                return;
            }
            lookIndex = position;
            verifiedLookIndex = -1;
            looksAdapter.select(position);
            updateProLabels();
            updateRepeating();
            show(position == 0 ? "Color natural" : "Look " + LOOKS[position] + " aplicado en Camera2; verifica resultado");
        });
        androidx.recyclerview.widget.RecyclerView looks = findViewById(R.id.look_recycler);
        looks.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(
                this, androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false));
        looks.setAdapter(looksAdapter);

        gridView = new GridView(); gridView.setVisibility(View.GONE);
        previewBox.addView(gridView, 1, new FrameLayout.LayoutParams(-1,-1));
        textureView.setSurfaceTextureListener(surfaceListener);
        textureView.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_UP) {
                focusOverlay.highlight(ev.getX(),ev.getY());
                touchMetering(ev.getX(), ev.getY());
                return true;
            }
            return true;
        });
        lastThumbnail.setOnClickListener(v -> openLastSaved());
        shutterButton.setOnClickListener(v -> {
            if (finalizingVideo) { show("Finalizando video; espera a Guardado"); return; }
            if (videoMode) {
                if (recording) stopRecording(true);
                else if (!startingRecording) startRecording();
            } else takePhoto();
        });
        photoModeButton.setOnClickListener(v -> changeMode(false));
        videoModeButton.setOnClickListener(v -> changeMode(true));
        cameraButton = findViewById(R.id.studio_flip);
        cameraButton.setOnClickListener(v -> flipCamera());
        gridButton = findViewById(R.id.studio_grid);
        gridButton.setOnClickListener(v -> {
            gridView.setVisibility(gridView.getVisibility()==View.VISIBLE ? View.GONE : View.VISIBLE);
            gridButton.setText(gridView.getVisibility()==View.VISIBLE ? "▦ ✓" : "▦");
        });
        proButton = findViewById(R.id.studio_menu);
        proButton.setOnClickListener(v -> {
            proExpanded = !proExpanded;
            advancedContainer.setVisibility(proExpanded ? View.VISIBLE : View.GONE);
            proButton.setText(proExpanded ? "CERRAR" : "PRO");
        });
        wbQuickButton = findViewById(R.id.studio_wb);
        wbQuickButton.setOnClickListener(v -> { wbIndex=(wbIndex+1)%WB_LABELS_K.length;
            updateProLabels();updateRepeating(); });
        manualToggle.setOnClickListener(v -> {
            if (!canUseManual()) return;
            if (isManualActive()) { isoIndex=0; speedIndex=0; }
            else { isoIndex=2;speedIndex=videoMode?2:1; }
            updateProLabels();updateRepeating();
        });
        shutterDial.configure("SHUTTER", SPEED_LABELS, index -> {
            if (!canUseManual()) return;
            speedIndex=index; updateProLabels(); updateRepeating();
        });
        String[] isoDialNames={"AUTO","100","200","400","800","1600"};
        isoDial.configure("ISO",isoDialNames,index -> {
            if (!canUseManual()) return;
            isoIndex=index;updateProLabels();updateRepeating();
        });
        evBar.setMax(40);evBar.setProgress(20);
        evBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar,int p,boolean user) {
                if (!user) return;
                manualEv=(p-20)/10f;updateExposureText();updateRepeating();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        protectButton.setOnClickListener(v -> {
            highlightGuard=!highlightGuard;
            protectButton.setText(highlightGuard ? "HL ON" : "HL OFF");
            updateExposureText();updateRepeating();
        });

        // Advanced controls are actual Camera2 handlers, not decorative buttons.
        LinearLayout row1 = horizontal();
        LinearLayout row2 = horizontal();
        LinearLayout row3 = horizontal();
        LinearLayout row4 = horizontal();
        isoButton=action("ISO AUTO",0xFF222832,WHITE,10);
        speedButton=action("S AUTO",0xFF222832,WHITE,10);
        wbButton=action("WB AUTO",0xFF222832,WHITE,10);
        flashButton=action("FLASH OFF",0xFF222832,WHITE,10);
        zoomButton=action("ZOOM 1×",0xFF222832,WHITE,10);
        aeLockButton=action("AE LIBRE",0xFF222832,WHITE,10);
        lookButton=action("COLOR NATURAL",0xFF222832,WHITE,10);
        afLockButton=action("AF LIBRE",0xFF222832,WHITE,10);
        qualityButton=action("VIDEO 1080",0xFF222832,WHITE,10);
        audioButton=action("AUDIO AMBIENTE",0xFF222832,WHITE,10);
        shutter180Button=action("180° · 1/60",0xFF222832,WHITE,10);
        addProRow(row1,isoButton,speedButton,wbButton);
        addProRow(row2,flashButton,zoomButton,aeLockButton);
        addProRow(row3,lookButton,afLockButton,qualityButton);
        addProRow(row4,audioButton,shutter180Button);
        proPanel.addView(row1);proPanel.addView(row2);
        proPanel.addView(row3);proPanel.addView(row4);
        isoButton.setOnClickListener(v->{if(!canUseManual())return;
            isoIndex=(isoIndex+1)%ISO_CHOICES.length; updateProLabels();updateRepeating();});
        speedButton.setOnClickListener(v->{if(!canUseManual())return;
            speedIndex=(speedIndex+1)%SPEED_CHOICES.length;updateProLabels();updateRepeating();});
        wbButton.setOnClickListener(v->{wbIndex=(wbIndex+1)%WB_KELVIN.length;
            updateProLabels();updateRepeating();});
        flashButton.setOnClickListener(v->{if(videoMode || cameraFacing!=CameraCharacteristics.LENS_FACING_BACK){
            show("Flash disponible solamente en fotografía trasera");return;}
            flashAuto=!flashAuto;updateProLabels();updateRepeating();});
        zoomButton.setOnClickListener(v->{zoomIndex=(zoomIndex+1)%3;updateProLabels();updateRepeating();});
        aeLockButton.setOnClickListener(v->{if(isManualActive()){
            show("Exposición manual ya fijada");return;}
            aeLocked=!aeLocked;updateProLabels();updateRepeating();});
        lookButton.setOnClickListener(v -> {
            int next = lookIndex;
            for (int i = 0; i < LOOKS.length; i++) {
                int candidate = (next + i + 1) % LOOKS.length;
                if (isLookAvailable(candidate)) { next = candidate; break; }
            }
            lookIndex = next;
            verifiedLookIndex = -1;
            looksAdapter.select(next);
            updateProLabels();
            updateRepeating();
        });
        afLockButton.setOnClickListener(v->toggleAfLock());
        qualityButton.setOnClickListener(v->{
            if(recording||startingRecording||finalizingVideo){show("Detén grabación para cambiar calidad");return;}
            int next=qualityIndex==1?0:1;
            if(next==1&&!supportsVideoSize(2560,1440)){show("1440p no anunciado en esta cámara");return;}
            qualityIndex=next;
            videoSize=next==1?new Size(2560,1440):new Size(1920,1080);
            updateProLabels();updateCameraMeta();
        });
        audioButton.setOnClickListener(v->{if(recording||startingRecording){show("Detén el video");return;}
            audioIndex=1-audioIndex;updateProLabels();
            show(audioIndex==1?"Voz: efectos dependen del fabricante":"Ambiente: sonido original");});
        shutter180Button.setOnClickListener(v->{
            if(!videoMode||!canUseManual()){show("Solo video manual 30 FPS");return;}
            speedIndex=2;updateProLabels();updateRepeating();
        });
        Button diagnose=action("DIAGNÓSTICO",0xFF222832,WHITE,10);
        diagnose.setOnClickListener(v->{if(recording||startingRecording){show("Detén video antes del diagnóstico");return;}
            startActivity(new Intent(this,MainActivity.class));});
        proPanel.addView(diagnose,new LinearLayout.LayoutParams(-1,dp(35)));
        Button histogramButton = action("HISTOGRAMA: OFF", 0xFF222832, WHITE, 10);
        histogramButton.setOnClickListener(v -> {
            boolean nowVisible = scopes.getVisibility() != View.VISIBLE;
            scopes.setVisibility(nowVisible ? View.VISIBLE : View.GONE);
            histogramButton.setText(nowVisible ? "HISTOGRAMA: ON" : "HISTOGRAMA: OFF");
        });
        proPanel.addView(histogramButton,new LinearLayout.LayoutParams(-1,dp(37)));
        updateProLabels();updateCameraMeta(); updateBattery();
        statusText.setText("Toca para enfocar y medir luz");
    }

    private void addProRow(LinearLayout row, Button... buttons) {
        for (Button b:buttons) {
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(37),1);
            lp.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(b,lp);
        }
    }

    private void updateBattery() {
        android.content.Intent battery = registerReceiver(null,
                new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null && batteryLabel!=null) {
            int level=battery.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL,-1);
            int scale=battery.getIntExtra(android.os.BatteryManager.EXTRA_SCALE,100);
            if (level>=0 && scale>0) batteryLabel.setText((level*100/scale)+"% ▰");
        }
    }

    private void updateCameraMeta() {
        if (metaText==null) return;
        boolean front=cameraFacing==CameraCharacteristics.LENS_FACING_FRONT;
        String f="f/?",focus=front?"FIJO":"AF";
        if (characteristics!=null) {
            float[] a=characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES);
            if (a!=null&&a.length>0) f=String.format(Locale.US,"f/%.1f",a[0]);
            Float minFocus=characteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
            if (minFocus!=null && minFocus==0f)focus="FIJO";
        }
        String q=(qualityIndex==1?"1440p":"1080p")+" | 30FPS | "+f+" | "+focus;
        metaText.setText(q);
        if (resolutionLabel!=null) resolutionLabel.setText("JPEG · "+(qualityIndex==1?"1440p30":"1080p30"));
        if (rawLabel!=null) {
            boolean raw=characteristics!=null && contains(
                    characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES),
                    CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW);
            rawLabel.setText(raw?"RAW DISP. (NO ACTIVO)":"RAW NO");
        }
    }

    private final Runnable scopesTick = new Runnable() {
        @Override public void run() {
            if (paused || scopes==null || textureView==null) return;
            try {
                if(scopes.getVisibility() == View.VISIBLE && textureView.isAvailable() && sessionReady) {
                    Bitmap bmp=textureView.getBitmap(128,80);
                    if(bmp!=null){scopes.setPreviewSample(bmp);bmp.recycle();}
                }
                int a=0;
                if(recording && recorder!=null) {
                    try{a=recorder.getMaxAmplitude();}catch(RuntimeException ignored){}
                }
                scopes.setAudioMeter(a,recording);
                if(recordTag!=null)recordTag.setText(recording?"● REC":"LISTA");
            } catch (Exception ignored) { }
            main.postDelayed(this,600);
        }
    };

    private final TextureView.SurfaceTextureListener surfaceListener = new TextureView.SurfaceTextureListener() {
        @Override public void onSurfaceTextureAvailable(SurfaceTexture t, int width, int height) { requestOrOpenCamera(); }
        @Override public void onSurfaceTextureSizeChanged(SurfaceTexture t, int width, int height) { configurePreviewMatrix(width, height); }
        @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture t) { return true; }
        @Override public void onSurfaceTextureUpdated(SurfaceTexture t) { }
    };

    private void show(String message) {
        main.post(() -> {
            statusText.setText(message);
            Toast.makeText(LuxCamActivity.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    private void setStatus(String message) { main.post(() -> statusText.setText(message)); }

    private void requestOrOpenCamera() {
        if (paused || !textureView.isAvailable() || cameraHandler == null) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        openCamera();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        boolean granted = grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == CAMERA_PERMISSION) {
            if (granted) requestOrOpenCamera(); else show("Necesitamos permiso de cámara para continuar");
        } else if (requestCode == MICROPHONE_PERMISSION) {
            if (granted) startRecording(); else show("Autoriza el micrófono para grabar video con audio");
        }
    }

    private void findCameraIds(CameraManager manager) throws CameraAccessException {
        if (backId != null && frontId != null) return;
        for (String id : manager.getCameraIdList()) {
            Integer facing = manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK && backId == null) backId = id;
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT && frontId == null) frontId = id;
        }
    }

    private void openCamera() {
        if (paused || device != null || openingCamera.get() || cameraHandler == null || !textureView.isAvailable()) return;
        CameraManager manager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            findCameraIds(manager);
            cameraId = cameraFacing == CameraCharacteristics.LENS_FACING_FRONT ? frontId : backId;
            if (cameraId == null) { show("No se encontró la cámara solicitada"); return; }
            characteristics = manager.getCameraCharacteristics(cameraId);
            isoRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            shutterRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            Float zoom = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            maxDigitalZoom = zoom == null ? 1f : zoom;
            int[] caps = characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            manualSensor = isoRange != null && shutterRange != null && contains(caps,
                CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR);
            isoIndex = speedIndex = 0;
            aeLocked = afLocked = false;
            tapFocusActive = false;
            focusRequestSerial++;
            lastAutoGains = null; lastAutoTransform = null;
            cropRegion = null;
            main.post(() -> {updateProLabels();updateCameraMeta();});
            Integer orientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrientation = orientation != null ? orientation : 90;
            evRange = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            Rational rational = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
            evStep = rational == null || rational.floatValue() <= 0 ? .1f : rational.floatValue();
            if (evRange == null) evRange = new Range<>(0, 0);
            Integer af = characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
            Integer ae = characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
            maxAfRegions = af != null ? af : 0;
            maxAeRegions = ae != null ? ae : 0;
            activeArray = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) { show("Camera2 no presenta tamaños de salida"); return; }
            previewSize = choosePreview(map.getOutputSizes(SurfaceTexture.class));
            Size photo = choosePhoto(map.getOutputSizes(android.graphics.ImageFormat.JPEG));
            if (previewSize == null || photo == null) { show("No hay tamaños JPEG o de visor compatibles"); return; }
            jpegReader = ImageReader.newInstance(photo.getWidth(), photo.getHeight(), android.graphics.ImageFormat.JPEG, 2);
            int megaPixels = Math.round((photo.getWidth() * photo.getHeight()) / 1_000_000f);
            main.post(() -> resolutionLabel.setText(megaPixels + " MP · " + videoSize.getHeight() + "p30"));
            jpegReader.setOnImageAvailableListener(reader -> savePhoto(reader), cameraHandler);
            if (qualityIndex == 1 && !supportsVideoSize(2560, 1440)) {
                qualityIndex = 0; videoSize = new Size(1920, 1080);
        lookIndex=0;
        verifiedLookIndex=-1;
        updateLookAvailability();
        if (looksAdapter!=null)looksAdapter.select(0);
            }
            if (!cameraLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) { show("Cámara ocupada: reintenta"); return; }
            try {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    cameraLock.release(); return;
                }
                final int openGeneration = generation;
                openingCamera.set(true);
                manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                    @Override public void onOpened(CameraDevice camera) {
                        releaseOpeningLock();
                        if (paused || openGeneration != generation) { camera.close(); return; }
                        device = camera;
                        main.post(() -> configurePreviewMatrix(textureView.getWidth(), textureView.getHeight()));
                        createPreviewSession();
                    }
                    @Override public void onDisconnected(CameraDevice camera) {
                        releaseOpeningLock(); camera.close(); device = null; setStatus("Cámara desconectada");
                    }
                    @Override public void onError(CameraDevice camera, int error) {
                        releaseOpeningLock(); camera.close(); device = null; setStatus("Error Camera2: " + error);
                    }
                }, cameraHandler);
            } catch (Exception e) { releaseOpeningLock(); throw e; }
        } catch (Exception e) {
            show("No se pudo abrir la cámara: " + e.getMessage());
            releaseImageReader();
        }
    }

    private boolean contains(int[] available, int desired) {
        if (available == null) return false;
        for (int v : available) if (v == desired) return true;
        return false;
    }

    private boolean canUseManual() {
        if (!manualSensor) {
            show("Este sensor no anuncia control manual de exposición");
            return false;
        }
        return true;
    }

    private boolean isManualActive() {
        return manualSensor && (isoIndex > 0 || speedIndex > 0);
    }

    private void updateProLabels() {
        if (isoButton == null) return;
        isoButton.setText("ISO " + (isoIndex == 0 ? (speedIndex > 0 ? "200*" : "AUTO") : ISO_CHOICES[isoIndex]));
        speedButton.setText("S " + (speedIndex == 0 && isoIndex > 0 ? "1/100*" : SPEED_LABELS[speedIndex]));
        wbButton.setText("WB " + WB_LABELS_K[wbIndex]);
        if (lookButton != null) lookButton.setText("COLOR " + LOOKS[lookIndex]);
        if (afLockButton != null) afLockButton.setText(afLocked ? "AF FIJA" : "AF LIBRE");
        if (qualityButton != null) qualityButton.setText(qualityIndex == 1 ? "VIDEO 1440" : "VIDEO 1080");
        if (audioButton != null) audioButton.setText(audioIndex == 1 ? "AUDIO VOZ" : "AUDIO AMBIENTE");
        if (shutter180Button != null) shutter180Button.setAlpha(videoMode && manualSensor ? 1f : .45f);
        flashButton.setText("FLASH " + (flashAuto ? "AUTO" : "OFF"));
        zoomButton.setText("ZOOM " + (zoomIndex + 1) + "×");
        aeLockButton.setText(aeLocked ? "AE FIJA" : "AE LIBRE");
        boolean manualAllowed = manualSensor;
        if (isoDial!=null) {isoDial.setEnabled(manualAllowed);isoDial.setAlpha(manualAllowed?1f:.38f);isoDial.setSelection(isoIndex);}
        if (shutterDial!=null) {shutterDial.setEnabled(manualAllowed);shutterDial.setAlpha(manualAllowed?1f:.38f);shutterDial.setSelection(speedIndex);}
        if (manualToggle!=null)manualToggle.setText(isManualActive()?"MANUAL":"AUTO");
        if (wbQuickButton!=null)wbQuickButton.setText("WB " + WB_LABELS_K[wbIndex]);
        isoButton.setAlpha(manualAllowed ? 1f : .45f);
        speedButton.setAlpha(manualAllowed ? 1f : .45f);
        flashButton.setAlpha(!videoMode && cameraFacing == CameraCharacteristics.LENS_FACING_BACK ? 1f : .45f);
        if (evBar != null) {
            evBar.setEnabled(!isManualActive());
            evBar.setAlpha(isManualActive() ? .4f : 1f);
        }
        updateExposureText();
    }

    private Size choosePhoto(Size[] sizes) {
        if (sizes == null || sizes.length == 0) return null;
        Size best43 = null;
        long largest = -1;
        for (Size s : sizes) {
            float ratio = s.getWidth() / (float) s.getHeight();
            long area = (long) s.getWidth() * s.getHeight();
            if (ratio > 1.30f && ratio < 1.37f && area > largest) {
                largest = area; best43 = s;
            }
        }
        if (best43 != null) return best43;
        Size best = sizes[0];
        for (Size s : sizes) if ((long)s.getWidth()*s.getHeight() > (long)best.getWidth()*best.getHeight()) best = s;
        return best;
    }

    private Size choosePreview(Size[] sizes) {
        if (sizes == null || sizes.length == 0) return null;
        // FOTO = 4:3 like the maximum JPEG; VIDEO = 16:9 like the encoded MP4.
        // Choose a moderate buffer for smooth live preview, never force 16:9
        // on a 4:3 photo or it misrepresents what is saved.
        int wantedW = videoMode ? 1920 : 1440;
        int wantedH = 1080;
        for (Size s : sizes)
            if (s.getWidth() == wantedW && s.getHeight() == wantedH) return s;
        float aspect = videoMode ? (16f/9f) : (4f/3f);
        Size best = null;
        for (Size s : sizes) {
            float r = s.getWidth() / (float)s.getHeight();
            long pixels = (long)s.getWidth()*s.getHeight();
            if (Math.abs(r - aspect) > .012f || pixels > 1920L*1080) continue;
            if (best == null || pixels > (long)best.getWidth()*best.getHeight()) best = s;
        }
        if (best != null) return best;
        return sizes[0];
    }

    /**
     * 5.1.3: On X678B the SurfaceTexture preview is upright in portrait but the
     * landscape TextureView shows it sideways. Correct ONLY the on-screen view.
     * The JPEG orientation and MediaRecorder orientation hint are unchanged.
     *
     * In landscape, rotate the viewport image by the inverse of display rotation.
     * The matrix uses independent X/Y compensation because the untransformed
     * TextureView stretches its camera image into its rectangular viewport.
     * Letterboxing is intentional; don't crop or distort the final scene.
     */
    private void configurePreviewMatrix(int width, int height) {
        if (width <= 0 || height <= 0 || previewSize == null || characteristics == null) return;
        int display = OrientationMath.rotationDegrees(
                getWindowManager().getDefaultDisplay().getRotation());
        boolean front = cameraFacing == CameraCharacteristics.LENS_FACING_FRONT;
        Matrix matrix = new Matrix();
        final float cx = width / 2f;
        final float cy = height / 2f;

        if (display == 90 || display == 270) {
            // Source currently looks sideways on the X678B landscape TextureView.
            // Rotate it to screen orientation, preserving 4:3 photo / 16:9 video.
            final float aspect = videoMode ? (16f / 9f) : (4f / 3f);
            final float fitW = Math.min(width, height * aspect);
            final float fitH = fitW / aspect;
            final float direction = display == 90 ? 1f : -1f;
            matrix.setValues(new float[] {
                    0f, direction * fitW / height, cx - direction * fitW / 2f,
                    -direction * fitH / width, 0f, cy + direction * fitH / 2f,
                    0f, 0f, 1f
            });
        } else {
            // Keep the ALREADY WORKING portrait preview transform unchanged.
            int relative = OrientationMath.previewRotation(sensorOrientation, display, front);
            boolean quarterTurn = relative == 90 || relative == 270;
            float contentWidth = quarterTurn ? previewSize.getHeight() : previewSize.getWidth();
            float contentHeight = quarterTurn ? previewSize.getWidth() : previewSize.getHeight();
            float contentAspect = contentWidth / contentHeight;
            float viewportAspect = width / (float) height;
            float sx = 1f, sy = 1f;
            if (viewportAspect > contentAspect) sx = contentAspect / viewportAspect;
            else sy = viewportAspect / contentAspect;
            matrix.setScale(sx, sy, cx, cy);
        }
        if (front) matrix.postScale(-1f, 1f, cx, cy);
        textureView.setTransform(matrix);
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (recording || startingRecording || finalizingVideo) {
            // MediaRecorder orientation is fixed until the MP4 is closed.
            textureView.post(() -> configurePreviewMatrix(textureView.getWidth(), textureView.getHeight()));
            return;
        }
        // Reinflate landscape/portrait XML only after closing preview session and camera.
        generation++;
        closeCamera();
        buildInterface();
        if (!paused) {
            if (textureView.isAvailable()) requestOrOpenCamera();
            else textureView.setSurfaceTextureListener(surfaceListener);
        }
        Uri latest = latestSavedUri;
        if (latest != null) saveExecutor.execute(() -> publishThumbnail(latest, thumbnailOf(latest)));
    }

    private boolean supportsVideoSize(int width, int height) {
        if (characteristics == null) return false;
        StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) return false;
        Size[] s = map.getOutputSizes(MediaRecorder.class);
        if (s == null) return false;
        for (Size size : s) if (size.getWidth() == width && size.getHeight() == height) return true;
        return false;
    }

    private void releaseOpeningLock() {
        if (openingCamera.getAndSet(false)) cameraLock.release();
    }

    private void closeCamera() {
        boolean acquired = false;
        try {
            acquired = cameraLock.tryAcquire(2500, TimeUnit.MILLISECONDS);
            if (!acquired) { setStatus("Cámara ocupada al cerrar"); return; }
            sessionReady = false;
            takingPhoto = false;
            if (captureSession != null) { captureSession.close(); captureSession = null; }
            if (device != null) { device.close(); device = null; }
            if (previewSurface != null) { previewSurface.release(); previewSurface = null; }
            releaseImageReader();
        } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        finally { if (acquired) cameraLock.release(); }
    }

    private void releaseImageReader() {
        if (jpegReader != null) { jpegReader.close(); jpegReader = null; }
    }

    private Surface prepareSurface() {
        SurfaceTexture texture = textureView.getSurfaceTexture();
        if (texture == null || previewSize == null) return null;
        texture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
        textureView.post(() -> configurePreviewMatrix(textureView.getWidth(), textureView.getHeight()));
        if (previewSurface != null) previewSurface.release();
        previewSurface = new Surface(texture);
        return previewSurface;
    }

    private void createPreviewSession() {
        if (paused || device == null || jpegReader == null) return;
        sessionReady = false;
        try {
            if (captureSession != null) { captureSession.close(); captureSession = null; }
            Surface surface = prepareSurface();
            if (surface == null) return;
            CaptureRequest.Builder builder = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(surface);
            setupControls(builder, false);
            final CameraDevice current = device;
            current.createCaptureSession(Arrays.asList(surface, jpegReader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    if (paused || current != device || recording || startingRecording) { session.close(); return; }
                    captureSession = session;
                    repeatingBuilder = builder;
                    sessionReady = true;
                    updateRepeating();
                    setStatus(cameraFacing == CameraCharacteristics.LENS_FACING_FRONT
                            ? "Frontal de foco fijo · Toca para medir luz"
                            : "Lista · Toca para enfocar y medir luz");
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) { setStatus("No se pudo configurar la vista previa"); }
            }, cameraHandler);
        } catch (Exception e) { show("Error de vista previa: " + e.getMessage()); }
    }

    private void setupControls(CaptureRequest.Builder b, boolean photo) {
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
        if (characteristics != null) {
            int[] anti = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_ANTIBANDING_MODES);
            if (contains(anti, CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO))
                b.set(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE, CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO);
            else if (contains(anti, CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_60HZ))
                b.set(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE, CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_60HZ);
        }
        if (isManualActive()) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
            int iso = isoIndex == 0 ? 200 : ISO_CHOICES[isoIndex];
            long shutter = speedIndex == 0 ? 10_000_000L : SPEED_CHOICES[speedIndex];
            b.set(CaptureRequest.SENSOR_SENSITIVITY, Math.max(isoRange.getLower(), Math.min(isoRange.getUpper(), iso)));
            long exposure = Math.max(shutterRange.getLower(), Math.min(shutterRange.getUpper(), shutter));
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposure);
            if (videoMode) b.set(CaptureRequest.SENSOR_FRAME_DURATION, Math.max(33_333_333L, exposure));
        } else {
            int aeMode = CaptureRequest.CONTROL_AE_MODE_ON;
            int[] available = characteristics == null ? null : characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
            if (photo && flashAuto && cameraFacing == CameraCharacteristics.LENS_FACING_BACK
                    && contains(available, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH))
                aeMode = CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH;
            b.set(CaptureRequest.CONTROL_AE_MODE, aeMode);
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, exposureUnits());
            b.set(CaptureRequest.CONTROL_AE_LOCK, aeLocked);
        }
        boolean canManualWb = characteristics != null && contains(
                characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES),
                CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING);
        int[] awb = characteristics == null ? null : characteristics.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
        if (wbIndex > 0 && canManualWb && contains(awb, CaptureRequest.CONTROL_AWB_MODE_OFF)
                && lastAutoGains != null && lastAutoTransform != null) {
            b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF);
            b.set(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX);
            b.set(CaptureRequest.COLOR_CORRECTION_TRANSFORM, lastAutoTransform);
            float w = (5600f - WB_KELVIN[wbIndex]) / 2400f;
            b.set(CaptureRequest.COLOR_CORRECTION_GAINS, new RggbChannelVector(
                    Math.max(1f, lastAutoGains.getRed() * (1f - 0.15f * w)),
                    lastAutoGains.getGreenEven(), lastAutoGains.getGreenOdd(),
                    Math.max(1f, lastAutoGains.getBlue() * (1f + 0.45f * w))));
        } else {
            b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
        }
        if (activeArray != null) {
            float zoom = Math.min(zoomIndex + 1, maxDigitalZoom);
            int cw = Math.max(1, Math.round(activeArray.width() / zoom));
            int ch = Math.max(1, Math.round(activeArray.height() / zoom));
            int left = activeArray.left + (activeArray.width() - cw) / 2;
            int top = activeArray.top + (activeArray.height() - ch) / 2;
            cropRegion = new Rect(left, top, left + cw, top + ch);
            b.set(CaptureRequest.SCALER_CROP_REGION, cropRegion);
        }
        b.set(CaptureRequest.CONTROL_AF_MODE,
                cameraFacing == CameraCharacteristics.LENS_FACING_BACK
                        ? ((afLocked || tapFocusActive) ? CaptureRequest.CONTROL_AF_MODE_AUTO :
                        (videoMode ? CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO : CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE))
                        : CaptureRequest.CONTROL_AF_MODE_OFF);
        if (aeRegions != null && maxAeRegions > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, aeRegions);
        if (afRegions != null && maxAfRegions > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, afRegions);
        if (photo) {
            b.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);
            b.set(CaptureRequest.JPEG_QUALITY, (byte) 100);
            chooseImageQuality(b, true);
        } else {
            b.set(CaptureRequest.CONTROL_CAPTURE_INTENT,
                    recording || startingRecording ? CaptureRequest.CONTROL_CAPTURE_INTENT_VIDEO_RECORD : CaptureRequest.CONTROL_CAPTURE_INTENT_PREVIEW);
            chooseImageQuality(b, false);
        }
        // Foto/visor: la AE debe poder alargar exposición en interiores.
        // Video: priorizamos 30 fps nominales, pendiente validar fps reales.
        Range<Integer>[] ranges = characteristics != null && !photo && (recording || startingRecording)
                ? characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) : null;
        if (ranges != null) {
            for (Range<Integer> r : ranges) {
                if (r.getLower() == 30 && r.getUpper() == 30) {
                    b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, r); break;
                }
            }
        }
    }

    private boolean isLookAvailable(int look) {
        if (look == 0) return true;
        if (characteristics == null) return false;
        if (look == 7) {
            return contains(characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS),
                    CaptureRequest.CONTROL_EFFECT_MODE_MONO);
        }
        int desired = look == 1 ? CaptureRequest.TONEMAP_MODE_PRESET_CURVE
                                : CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE;
        return contains(characteristics.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES), desired);
    }

    private void updateLookAvailability() {
        if (looksAdapter == null) return;
        boolean[] availability = new boolean[LOOKS.length];
        for (int i = 0; i < LOOKS.length; i++) availability[i] = isLookAvailable(i);
        main.post(() -> { if (looksAdapter != null) looksAdapter.setAvailability(availability); });
    }

    private void chooseImageQuality(CaptureRequest.Builder b, boolean still) {
        setSupported(b, CaptureRequest.NOISE_REDUCTION_MODE,
                CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES,
                still ? CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY : CaptureRequest.NOISE_REDUCTION_MODE_FAST);
        // No forzamos EDGE HIGH_QUALITY: podria introducir halos de nitidez.
        if (lookIndex == 1 && isLookAvailable(1)) {
            // Rec.709 preset, actually requested on preview, JPEG and encoder streams.
            b.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_PRESET_CURVE);
            b.set(CaptureRequest.TONEMAP_PRESET_CURVE, CaptureRequest.TONEMAP_PRESET_CURVE_REC709);
        } else if (lookIndex >= 2 && lookIndex <= 6 && isLookAvailable(lookIndex)) {
            // Genuine 1D RGB tone LUT via the camera ISP, not OpenGL/3D LUT.
            float[][] curves = LuxToneCurves.forLook(lookIndex);
            b.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE);
            b.set(CaptureRequest.TONEMAP_CURVE,
                    new android.hardware.camera2.params.TonemapCurve(curves[0], curves[1], curves[2]));
        } else {
            setSupported(b, CaptureRequest.TONEMAP_MODE,
                    CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES,
                    CaptureRequest.TONEMAP_MODE_HIGH_QUALITY);
        }
        if (lookIndex == 7 && isLookAvailable(7)) {
            b.set(CaptureRequest.CONTROL_EFFECT_MODE, CaptureRequest.CONTROL_EFFECT_MODE_MONO);
        } else {
            b.set(CaptureRequest.CONTROL_EFFECT_MODE, CaptureRequest.CONTROL_EFFECT_MODE_OFF);
        }
        setSupported(b, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES,
                still ? CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY : CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_FAST);
    }

    private void setSupported(CaptureRequest.Builder b, CaptureRequest.Key<Integer> key,
                              CameraCharacteristics.Key<int[]> capabilities, int desired) {
        if (characteristics == null) return;
        int[] available = characteristics.get(capabilities);
        if (available == null) return;
        for (int mode : available) if (mode == desired) { b.set(key, desired); return; }
    }

    private int exposureUnits() {
        float effective = manualEv - (highlightGuard ? .3f : 0f);
        int steps = Math.round(effective / evStep);
        return Math.max(evRange.getLower(), Math.min(evRange.getUpper(), steps));
    }

    private void updateExposureText() {
        float effective = manualEv - (highlightGuard ? .3f : 0f);
        evLabel.setText(isManualActive() ? "M · EV desactivada" : String.format(Locale.US, "%+.1f EV", effective));
    }

    private void updateRepeating() {
        if (!sessionReady || captureSession == null || repeatingBuilder == null || cameraHandler == null) return;
        try {
            setupControls(repeatingBuilder, false);
            captureSession.setRepeatingRequest(repeatingBuilder.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request,
                        TotalCaptureResult result) {
                    // The camera HAL can advertise custom tonemapping but ignore it.
                    // Only claim active application when the CaptureResult confirms the mode.
                    int selected = lookIndex;
                    if (selected != 0 && verifiedLookIndex != selected && !recording && !takingPhoto) {
                        Integer actual = result.get(CaptureResult.TONEMAP_MODE);
                        int expected = selected == 1 ? CaptureRequest.TONEMAP_MODE_PRESET_CURVE
                                : selected == 7 ? CaptureRequest.TONEMAP_MODE_HIGH_QUALITY
                                : CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE;
                        // MONO is an effect, so check effect result instead of tonemap mode.
                        Integer actualEffect = selected == 7 ? result.get(CaptureResult.CONTROL_EFFECT_MODE) : null;
                        if (selected == 7 ? actualEffect != null : actual != null) {
                            boolean accepted = selected == 7
                                    ? actualEffect == CaptureRequest.CONTROL_EFFECT_MODE_MONO
                                    : actual == expected;
                            verifiedLookIndex = selected;
                            setStatus(accepted ? "Look " + LOOKS[selected] + " reconocido por Camera2"
                                    : "La cámara no confirmó este look; usa Natural");
                        }
                    }
                    if (wbIndex == 0) {
                        RggbChannelVector g = result.get(CaptureResult.COLOR_CORRECTION_GAINS);
                        ColorSpaceTransform t = result.get(CaptureResult.COLOR_CORRECTION_TRANSFORM);
                        if (g != null && t != null) { lastAutoGains = g; lastAutoTransform = t; }
                    }
                }
            }, cameraHandler);
        } catch (Exception e) { setStatus("Exposición no aplicada: " + e.getMessage()); }
    }

    private void toggleAfLock() {
        if (cameraFacing != CameraCharacteristics.LENS_FACING_BACK || captureSession == null || device == null) {
            show("El AF Lock requiere una cámara con enfoque automático"); return;
        }
        afLocked = !afLocked;
        updateProLabels();
        if (!afLocked) { updateRepeating(); return; }
        try {
            // Stop continuous AF and perform a one-shot focus. AUTO retains the
            // focus until the AF mode is changed or the trigger is cancelled.
            CaptureRequest.Builder lock = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            lock.addTarget(previewSurface);
            setupControls(lock, false);
            lock.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
            lock.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
            captureSession.capture(lock.build(), null, cameraHandler);
            updateRepeating();
        } catch (Exception e) { afLocked = false; updateProLabels(); show("No se pudo bloquear enfoque"); }
    }

    private void takePhoto() {
        if (!sessionReady || cameraHandler == null || takingPhoto || recording || device == null || captureSession == null) {
            show("Espera a que la cámara esté lista"); return;
        }
        takingPhoto = true;
        saveNotice("CAPTURANDO FOTO…");
        try {
            CaptureRequest.Builder photo = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            photo.addTarget(jpegReader.getSurface());
            setupControls(photo, true);
            photo.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation());
            captureSession.capture(photo.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult result) {
                    // La confirmación de guardado se produce al publicar en MediaStore, no aquí.
                }
                @Override public void onCaptureFailed(CameraCaptureSession s, CaptureRequest r,
                        android.hardware.camera2.CaptureFailure failure) {
                    takingPhoto = false;
                    setStatus("No se pudo capturar la foto");
                }
            }, cameraHandler);
        } catch (Exception e) { takingPhoto = false; show("Error de fotografía: " + e.getMessage()); }
    }

    private String timestamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date()); }

    /** Se liberan los buffers de Camera2 rápidamente; el trabajo de disco se hace fuera del hilo de cámara. */
    private void savePhoto(ImageReader reader) {
        Image image = null;
        byte[] bytes;
        try {
            image = reader.acquireNextImage();
            if (image == null) { takingPhoto = false; return; }
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
        } catch (Exception e) {
            takingPhoto = false;
            saveNotice("ERROR DE CAPTURA");
            return;
        } finally {
            if (image != null) image.close();
        }
        takingPhoto = false;
        saveNotice("GUARDANDO FOTO…");
        saveExecutor.execute(() -> writeJpegToMediaStore(bytes));
    }

    private void saveNotice(String notice) {
        main.post(() -> { if (savedHint != null) savedHint.setText(notice); });
    }

    private void writeJpegToMediaStore(byte[] bytes) {
        Uri uri = null;
        try {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "LuxCam_" + timestamp() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, PICTURES_FOLDER);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("MediaStore no reservó el JPEG");
            try (OutputStream out = resolver.openOutputStream(uri, "w")) {
                if (out == null) throw new IOException("JPEG no disponible");
                out.write(bytes);
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            if (resolver.update(uri, done, null, null) < 1) throw new IOException("No se pudo publicar JPEG");
            confirmSaved(uri, "image/jpeg", null, "✓ FOTO GUARDADA");
            Bitmap thumbnail = thumbnailOf(uri);
            publishThumbnail(uri, thumbnail);
        } catch (Exception e) {
            if (uri != null) { try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {} }
            saveNotice("ERROR AL GUARDAR FOTO");
            setStatus("No se guardó la foto: " + e.getMessage());
        }
    }

    private Bitmap thumbnailOf(Uri uri) {
        try { return getContentResolver().loadThumbnail(uri, new Size(192, 192), null); }
        catch (Exception ignored) { return null; }
    }

    private void confirmSaved(Uri uri, String mime, Bitmap bitmap, String label) {
        main.post(() -> {
            latestSavedUri = uri;
            latestSavedMime = mime;
            if (bitmap != null && lastThumbnail != null) lastThumbnail.setImageBitmap(bitmap);
            if (savedHint != null) savedHint.setText(label + " · TOCA LA MINIATURA");
            if (statusText != null) statusText.setText(label);
        });
    }

    private void publishThumbnail(Uri uri, Bitmap bitmap) {
        if (bitmap == null) return;
        main.post(() -> {
            if (uri.equals(latestSavedUri) && lastThumbnail != null)
                lastThumbnail.setImageBitmap(bitmap);
        });
    }

    private void openLastSaved() {
        Uri uri = latestSavedUri;
        if (uri == null) { show("La miniatura aparecerá al terminar de guardar"); return; }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, latestSavedMime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) { show("No hay una aplicación compatible para abrir el archivo"); }
    }

    /** Convert display rotation to JPEG and MP4 orientation metadata.
     * Physical orientation only acts as a fallback when the screen is locked in portrait.
     */
    private int jpegOrientation() {
        int display = OrientationMath.rotationDegrees(getWindowManager().getDefaultDisplay().getRotation());
        int physical = physicalOrientation;
        boolean front = cameraFacing == CameraCharacteristics.LENS_FACING_FRONT;
        if (display == 0 && physical != OrientationEventListener.ORIENTATION_UNKNOWN &&
                getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT &&
                physical != 0) {
            // Sensor reports clockwise physical degrees; surface reports counter-clockwise
            // display rotation. Do not equate these two coordinate systems.
            return OrientationMath.jpegFromClockwiseSensor(sensorOrientation, physical, front);
        }
        return OrientationMath.jpegFromDisplay(sensorOrientation, display, front);
    }

    private void startRecording() {
        if (!videoMode || !sessionReady || device == null || startingRecording || recording || finalizingVideo) {
            show("Espera a que la cámara esté lista para grabar"); return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MICROPHONE_PERMISSION); return;
        }
        startingRecording = true;
        saveNotice("PREPARANDO VIDEO…");
        sessionReady = false;
        try {
            configureRecorder();
            captureSession.close();
            captureSession = null;
            final CameraDevice current = device;
            Surface preview = previewSurface;
            Surface record = recorder.getSurface();
            CaptureRequest.Builder b = current.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            b.addTarget(preview); b.addTarget(record);
            setupControls(b, false);
            current.createCaptureSession(Arrays.asList(preview, record), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    if (current != device || paused) { session.close(); cleanupVideo(false); return; }
                    captureSession = session;
                    repeatingBuilder = b;
                    try {
                        session.setRepeatingRequest(b.build(), null, cameraHandler);
                        recorder.start();
                        recording = true;
                        startingRecording = false;
                        sessionReady = true;
                        recordStartMs = android.os.SystemClock.elapsedRealtime();
                        // MP4 orientation is fixed per file. Keep the UI orientation fixed while recording.
                        main.post(() -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED));
                        main.post(() -> {
                            shutterButton.setText("■");
                            shutterButton.setTextColor(0xFFEA515C);
                            timerText.setText("● 00:00 · GRABANDO");
                            setStatus("Grabando " + videoSize.getHeight() + "p · Audio AAC");
                            saveNotice("● GRABACIÓN EN CURSO");
                            tickTimer.run();
                        });
                    } catch (Exception e) { failVideo("Error iniciando grabación", e); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {
                    session.close();
                    failVideo("Sesión de video no compatible", null);
                }
            }, cameraHandler);
        } catch (Exception e) { failVideo("No se pudo preparar video", e); }
    }

    private void configureRecorder() throws IOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "LuxCam_" + timestamp() + ".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, VIDEOS_FOLDER);
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (videoUri == null) throw new IOException("No se pudo crear archivo MP4");
        videoFd = getContentResolver().openFileDescriptor(videoUri, "w");
        if (videoFd == null) throw new IOException("No hay descriptor de video");
        recorder = new MediaRecorder();
        // CAMCORDER permite a la HAL elegir el procesamiento de microfono apropiado.
        // No se anuncia reducción de ruido por IA sin verificarla con audio real.
        recorder.setAudioSource(audioIndex == 1 ? MediaRecorder.AudioSource.VOICE_COMMUNICATION
                : MediaRecorder.AudioSource.CAMCORDER);
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setOutputFile(videoFd.getFileDescriptor());
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(videoSize.getWidth(), videoSize.getHeight());
        recorder.setVideoFrameRate(30);
        recorder.setVideoEncodingBitRate(qualityIndex == 1 ? 35_000_000 : 20_000_000);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        recorder.setAudioEncodingBitRate(192_000);
        recorder.setAudioSamplingRate(48_000);
        recorder.setAudioChannels(1); // conservador: el HAL previo solo garantizó mono; verificar estéreo después.
        recordingOrientationHint = jpegOrientation();
        recorder.setOrientationHint(recordingOrientationHint);
        recorder.prepare();
    }

    /** La finalización MP4 puede durar segundos; nunca bloquear la interfaz principal. */
    private void stopRecording(boolean resumePreview) {
        if ((!recording && !startingRecording) || finalizingVideo) return;
        boolean wasRecording = recording;
        finalizingVideo = true;
        recording = false;
        startingRecording = false;
        sessionReady = false;
        main.removeCallbacks(tickTimer);
        saveNotice("FINALIZANDO VIDEO…");
        setStatus("Finalizando archivo MP4; espera confirmación");
        try {
            if (captureSession != null) {
                captureSession.stopRepeating();
                captureSession.abortCaptures();
                captureSession.close(); captureSession = null;
            }
        } catch (Exception ignored) { }
        main.post(() -> {
            shutterButton.setEnabled(false);
            shutterButton.setText("…");
            timerText.setText("FINALIZANDO…");
        });
        saveExecutor.execute(() -> {
            boolean saved = false;
            Uri completedUri = videoUri;
            if (wasRecording && recorder != null) {
                try { recorder.stop(); saved = true; }
                catch (RuntimeException ignored) { saved = false; }
            }
            final boolean success = cleanupVideo(saved);
            main.post(() -> {
                finalizingVideo = false;
                if (!paused) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
                shutterButton.setEnabled(true);
                shutterButton.setText("●");
                shutterButton.setTextColor(0xFFEA515C);
                timerText.setText("");
                if (success && completedUri != null) {
                    confirmSaved(completedUri, "video/mp4", null, "✓ VIDEO GUARDADO");
                } else {
                    saveNotice("ERROR: VIDEO NO GUARDADO");
                    setStatus("No se pudo cerrar el archivo MP4");
                }
                if (resumePreview && !paused && device != null && cameraHandler != null)
                    createPreviewSession();
            });
            if (success && completedUri != null) {
                Bitmap thumbnail = thumbnailOf(completedUri);
                publishThumbnail(completedUri, thumbnail);
            }
        });
    }

    private boolean cleanupVideo(boolean successful) {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) { }
            recorder.release(); recorder = null;
        }
        if (videoFd != null) {
            try { videoFd.close(); } catch (IOException ignored) { }
            videoFd = null;
        }
        boolean published = false;
        if (videoUri != null) {
            try {
                if (successful) {
                    ContentValues update = new ContentValues();
                    update.put(MediaStore.Video.Media.IS_PENDING, 0);
                    published = getContentResolver().update(videoUri, update, null, null) > 0;
                }
                if (!published) getContentResolver().delete(videoUri, null, null);
            } catch (Exception ignored) {
                try { getContentResolver().delete(videoUri, null, null); } catch (Exception ignored2) { }
            }
            videoUri = null;
        }
        return published;
    }

    private void failVideo(String reason, Exception e) {
        recording = false; startingRecording = false; sessionReady = false;
        main.post(() -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        cleanupVideo(false);
        String msg = reason + (e != null && e.getMessage() != null ? ": " + e.getMessage() : "");
        setStatus(msg);
        main.post(() -> { shutterButton.setText("●"); shutterButton.setTextColor(0xFFEA515C); timerText.setText(""); });
        if (!paused && device != null) main.postDelayed(this::createPreviewSession, 250);
    }

    private final Runnable tickTimer = new Runnable() {
        @Override public void run() {
            if (!recording) return;
            long seconds = (android.os.SystemClock.elapsedRealtime() - recordStartMs) / 1000;
            timerText.setText(String.format(Locale.US, "● %02d:%02d · GRABANDO", seconds / 60, seconds % 60));
            main.postDelayed(this, 1000);
        }
    };

    private void changeMode(boolean video) {
        if (recording || startingRecording || finalizingVideo) { show("Espera a que el video se guarde"); return; }
        videoMode = video;
        if (lookIndex == 1 && characteristics == null) lookIndex = 0;
        if (video) { flashAuto = false; }
        aeLocked = false;
        updateProLabels();
        photoModeButton.setBackground(background(video ? 0xFF263343 : ACCENT, 24, Color.TRANSPARENT));
        photoModeButton.setTextColor(video ? WHITE : PANEL);
        videoModeButton.setBackground(background(video ? ACCENT : 0xFF263343, 24, Color.TRANSPARENT));
        videoModeButton.setTextColor(video ? PANEL : WHITE);
        shutterButton.setText("●"); shutterButton.setTextColor(video ? 0xFFEA515C : PANEL);
        if (headingSub != null) headingSub.setText(video ? "CAMERA2  ·  VIDEO" : "CAMERA2  ·  FOTO");
        updateCameraMeta();
        setStatus(video ? "Video " + videoSize.getHeight() + "p · Toca grabar" : "Foto JPEG original · Toca para enfocar");
        // A photo preview must be 4:3; video uses 16:9. Recreate only its
        // CameraCaptureSession so the image matches the final framing.
        if (device != null && characteristics != null) {
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size desired = choosePreview(map.getOutputSizes(SurfaceTexture.class));
                if (desired != null && !desired.equals(previewSize)) {
                    previewSize = desired;
                    sessionReady = false;
                    createPreviewSession();
                    textureView.post(() -> configurePreviewMatrix(textureView.getWidth(), textureView.getHeight()));
                    return;
                }
            }
        }
        updateRepeating();
    }

    private void flipCamera() {
        if (recording || startingRecording || takingPhoto || finalizingVideo) { show("Espera a que se guarde la captura"); return; }
        generation++;
        sessionReady = false;
        cameraFacing = cameraFacing == CameraCharacteristics.LENS_FACING_BACK
                ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK;
        afRegions = null; aeRegions = null;
        wbIndex = isoIndex = speedIndex = zoomIndex = 0;
        lastAutoGains = null; lastAutoTransform = null;
        qualityIndex = 0; videoSize = new Size(1920, 1080);
        lookIndex=0;
        verifiedLookIndex=-1;
        updateLookAvailability();
        if (looksAdapter!=null)looksAdapter.select(0);
        afLocked = false;
        tapFocusActive = false;
        focusRequestSerial++;
        flashAuto = aeLocked = false;
        updateProLabels();
        closeCamera();
        updateCameraMeta();
        setStatus("Cambiando cámara…");
        main.postDelayed(this::requestOrOpenCamera, 350);
    }

    private void touchMetering(float x, float y) {
        if (activeArray == null || !sessionReady || captureSession == null) return;
        int w = textureView.getWidth();
        int h = textureView.getHeight();
        if (w <= 0 || h <= 0 || previewSize == null || x < 0 || y < 0 || x > w || y > h) return;
        // Touch and sensor must use the same mapping as the visible preview.
        Matrix previewTransform = new Matrix();
        Matrix inverse = new Matrix();
        textureView.getTransform(previewTransform);
        if (!previewTransform.invert(inverse)) return;
        float[] point = { x, y };
        inverse.mapPoints(point);
        float nx = point[0] / w;
        float ny = point[1] / h;
        // Reject taps on black letterboxing outside the image.
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return;
        int displayDegrees = OrientationMath.rotationDegrees(
                getWindowManager().getDefaultDisplay().getRotation());
        int relative = OrientationMath.previewRotation(sensorOrientation, displayDegrees,
                cameraFacing == CameraCharacteristics.LENS_FACING_FRONT);
        float sensorX, sensorY;
        switch (relative) {
            case 90: sensorX = ny; sensorY = 1f - nx; break;
            case 180: sensorX = 1f - nx; sensorY = 1f - ny; break;
            case 270: sensorX = 1f - ny; sensorY = nx; break;
            default: sensorX = nx; sensorY = ny; break;
        }
        Rect r = cropRegion == null ? activeArray : cropRegion;
        int px = r.left + Math.round(sensorX * r.width());
        int py = r.top + Math.round(sensorY * r.height());
        int side = Math.max(70, Math.min(activeArray.width(), activeArray.height()) / 7);
        int left = Math.max(activeArray.left, Math.min(px - side / 2, activeArray.right - side));
        int top = Math.max(activeArray.top, Math.min(py - side / 2, activeArray.bottom - side));
        MeteringRectangle[] box = new MeteringRectangle[]{new MeteringRectangle(left, top, side, side, 1000)};
        if (maxAeRegions > 0) aeRegions = box;
        if (maxAfRegions > 0 && cameraFacing == CameraCharacteristics.LENS_FACING_BACK) afRegions = box;
        // Camera2 metering rectangle alone does not initiate a one-shot autofocus.
        // Temporarily switch the back camera to AF_AUTO, trigger a scan and
        // return to continuous AF after a short timeout. The user can wait for
        // the focus box to settle before shooting moving subjects.
        if (cameraFacing == CameraCharacteristics.LENS_FACING_BACK &&
                !videoMode && !afLocked && previewSurface != null &&
                device != null && cameraHandler != null) {
            tapFocusActive = true;
            int token = ++focusRequestSerial;
            updateRepeating();
            try {
                CaptureRequest.Builder focus = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                focus.addTarget(previewSurface);
                setupControls(focus, false);
                focus.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
                focus.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
                captureSession.capture(focus.build(), null, cameraHandler);
                setStatus("Enfocando sujeto… Espera un instante antes de disparar");
                main.postDelayed(() -> {
                    if (focusRequestSerial != token) return;
                    tapFocusActive = false;
                    if (!paused && !recording) updateRepeating();
                }, 2300);
            } catch (Exception error) {
                tapFocusActive = false;
                updateRepeating();
                setStatus("No se pudo iniciar enfoque: " + error.getMessage());
            }
        } else {
            updateRepeating();
            setStatus("Medición de luz en el punto seleccionado");
        }
    }

    private final class GridView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        GridView() { super(LuxCamActivity.this); setClickable(false); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            paint.setColor(0x99FFFFFF); paint.setStrokeWidth(dp(1));
            float w = getWidth(), h = getHeight();
            for (int i = 1; i <= 2; i++) {
                canvas.drawLine(i * w / 3f, 0, i * w / 3f, h, paint);
                canvas.drawLine(0, i * h / 3f, w, i * h / 3f, paint);
            }
        }
    }
}
