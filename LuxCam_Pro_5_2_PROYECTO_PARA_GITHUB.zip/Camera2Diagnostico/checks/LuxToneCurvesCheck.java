package com.altoke.camera2diagnostico;

/** Pure Java checks; hardware application remains to be tested on X678B. */
public final class LuxToneCurvesCheck {
    public static void main(String[] args) {
        for (int look = 2; look <= 6; look++) {
            float[][] curves = LuxToneCurves.forLook(look);
            if (curves.length != 3) throw new AssertionError("3 channels required");
            for (int c = 0; c < 3; c++) {
                float[] lut = curves[c];
                if (lut.length != 64) throw new AssertionError("32 sampled pairs");
                float prevX = -1f, prevY = -1f;
                for (int i = 0; i < lut.length; i += 2) {
                    float x = lut[i], y = lut[i + 1];
                    if (x < 0 || x > 1 || y < 0 || y > 1)
                        throw new AssertionError("out of bounds: look " + look);
                    if (x <= prevX || y < prevY)
                        throw new AssertionError("nonmonotone at look " + look + ", channel " + c);
                    prevX = x; prevY = y;
                }
            }
        }
        System.out.println("LuxToneCurves: 15 channel LUTs validated; hardware pending");
    }
}
