package com.altoke.camera2diagnostico;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/**
 * Looks JPEG locales y reversibles. NUNCA sustituye el JPEG original.
 * No es Smart HDR, IA facial ni un filtro de vídeo.
 * Siempre ejecutarlo en saveExecutor, no en el hilo Camera2/UI.
 */
public final class LuxSmartPhoto {
    private LuxSmartPhoto() {}

    /** @return JPEG mejorado o null si falló (el original ya se guardó). */
    public static byte[] enhance(byte[] jpeg, int look) {
        if (jpeg == null || look < 1 || look > 7) return null;
        Bitmap input = null;
        Bitmap target = null;
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            input = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length, opts);
            if (input == null) return null;
            int w = input.getWidth(), h = input.getHeight();
            if (w < 1 || h < 1 || (long)w * h > 18000000L) return null;
            int[] pix = new int[w * h];
            input.getPixels(pix, 0, w, 0, 0, w, h);
            // La curva mantiene negros y blancos (no puede recuperar zonas quemadas).
            for (int i = 0; i < pix.length; i++) pix[i] = LuxColorMath.pixel(pix[i], look);
            target = Bitmap.createBitmap(pix, w, h, Bitmap.Config.ARGB_8888);
            // Aplicar la orientación EXIF a los píxeles del JPEG reprocesado.
            int orientation = ExifInterface.ORIENTATION_NORMAL;
            try (ByteArrayInputStream in = new ByteArrayInputStream(jpeg)) {
                ExifInterface exif = new ExifInterface(in);
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL);
            } catch (Exception ignored) { }
            Matrix m = exifTransform(orientation);
            if (!m.isIdentity()) {
                Bitmap oriented = Bitmap.createBitmap(target, 0, 0, target.getWidth(), target.getHeight(), m, true);
                target.recycle(); target = oriented;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(8192, jpeg.length));
            if (!target.compress(Bitmap.CompressFormat.JPEG, 97, out)) return null;
            return out.toByteArray();
        } catch (OutOfMemoryError | RuntimeException ex) {
            return null; // nunca afectar JPEG original
        } finally {
            if (target != null && !target.isRecycled()) target.recycle();
            if (input != null && !input.isRecycled()) input.recycle();
        }
    }

    private static Matrix exifTransform(int o) {
        Matrix m = new Matrix();
        switch (o) {
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_180: m.postRotate(180); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: m.postScale(1, -1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE: m.postRotate(90); m.postScale(-1,1); break;
            case ExifInterface.ORIENTATION_ROTATE_90: m.postRotate(90); break;
            case ExifInterface.ORIENTATION_TRANSVERSE: m.postRotate(270); m.postScale(-1,1); break;
            case ExifInterface.ORIENTATION_ROTATE_270: m.postRotate(270); break;
            default: break;
        }
        return m;
    }
}
