package com.altoke.camera2diagnostico;

/** Funciones de looks fotográficos 8-bit, sin dependencias Android. */
public final class LuxColorMath {
    private LuxColorMath() {}
    private static int clip(int x) { return Math.max(0, Math.min(255,x)); }
    /** look: 1 retrato, 2 cine suave, 3 cálido, 4 frío, 5 fade, 6 contraste, 7 mono. */
    public static int pixel(int argb, int look) {
        int a = (argb >>> 24)&255, r=(argb>>>16)&255, g=(argb>>>8)&255, b=argb&255;
        int lum = (54*r + 183*g + 19*b) >> 8;
        float y=lum/255f;
        // Sombras suaves con anclaje del negro (sin gamma lineal del sensor).
        float shadow=4f*y*(1-y)*(1-y);
        float lift;
        if (look==1) lift=35f;         // retrato: ilumina piel oscura sin cambiar rasgos
        else if (look==2) lift=24f;    // cine suave
        else if (look==3||look==4) lift=18f;
        else if (look==5) lift=15f;
        else if (look==6) lift=7f;
        else lift=9f;
        float delta=lift*shadow;
        if (look==6) delta += 9f*(2*y-1)*y*(1-y); // sutil contraste
        if (look==5) delta += 3f*(1-y);           // leve fade
        int rr=clip(Math.round(r+delta));
        int gg=clip(Math.round(g+delta));
        int bb=clip(Math.round(b+delta));
        if (look==3) { rr=clip(rr+3); bb=clip(bb-3); }
        if (look==4) { rr=clip(rr-2); bb=clip(bb+3); }
        if (look==7) {
            int mono=clip((54*rr+183*gg+19*bb)>>8);
            rr=gg=bb=mono;
        }
        return a<<24 | rr<<16 | gg<<8 | bb;
    }
}
