package com.altoke.camera2diagnostico;

/** Pruebas JVM que no necesitan un dispositivo Android. */
public final class LuxColorMathCheck {
    static void ensure(boolean ok,String s) { if (!ok) throw new AssertionError(s); }
    public static void main(String[] args) {
        for (int look=1;look<=7;look++) {
            for(int v=0;v<=255;v++) {
                int pixel=0xff000000 | (v<<16) | (v<<8) | v;
                int rgb=LuxColorMath.pixel(pixel,look);
                ensure((rgb>>>24)==255,"alpha "+look);
                int r=(rgb>>>16)&255,g=(rgb>>>8)&255,b=rgb&255;
                ensure(r>=0&&r<=255&&g>=0&&g<=255&&b>=0&&b<=255,"rgb range");
                if (look != 6) ensure((54*r+183*g+19*b)/256 >= v-5,"Look cannot blacken grays");
            }
        }
        int mid=0xff454545, portrait=LuxColorMath.pixel(mid,1);
        ensure((portrait&0xff)>0x45,"Portrait must open shadows");
        ensure(LuxColorMath.pixel(0xff000000,1) == 0xff000000,"preserve pure black");
        ensure(LuxColorMath.pixel(0xffffffff,1) == 0xffffffff,"preserve pure white");
        System.out.println("OK: 7 looks x 256 tones; preserve endpoints, no black crush");
    }
}
