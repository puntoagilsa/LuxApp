# LuxCam vs cámara original — Infinix X678B

Evaluación de los archivos compartidos el 15/10/2026. **Las fotos no son capturas equivalentes cuadro a cuadro y podrían haberse reducido al compartirlas**. No permite concluir superioridad de un sistema ni medir rango dinámico real del sensor.

| Tipo | Archivo original | Archivo LuxCam | Dato verificable |
| --- | --- | --- | --- |
| Foto trasera | `original.jpg` | `luxapp.jpg` | 960×1280 ambos archivos recibidos; encuadre/momento distintos. LuxCam más brillante y más propenso a luces intensas. |
| Foto frontal | `original frebte.jpg` | `frente lux.jpg` | 960×1280 ambos archivos recibidos. Encuadres, posición de fondo y luz distintos. |
| Video | `vieo original.mp4` | `video luxapp.mp4` | Ambos H.264, 720×1280 recibidos. Original ~58,25 fps promedio; LuxCam ~29,94 fps promedio. |
| Audio | `vieo original.mp4` | `video luxapp.mp4` | Original AAC estéreo/48 kHz/~256 kbps; LuxCam AAC mono/44,1 kHz/~128 kbps. |

### Observaciones de imagen (archivos recibidos)
- El interior detrás del sujeto sale bastante oscuro con la cámara original, mientras que la captura LuxCam general se percibe más clara.
- En LuxCam los blancos del primer plano están cercanos a saturación más a menudo en la muestra trasera; se debe priorizar preservación de luces antes que incrementar brillo general.
- Las capturas frontales son comparables en brillo de rostro, pero los cambios de posición e iluminación impiden atribuir diferencias de piel, nitidez o rango dinámico exclusivamente a la aplicación.
- Las capturas de video son de duraciones diferentes (original ~5,17 s, LuxCam ~15,14 s), no idénticas. Más FPS no implica automáticamente mejor imagen: representa mayor fluidez, con compromisos de exposición/ruido.
- Para comparar calidad objetiva se requieren los JPEG/MP4 **directamente extraídos de almacenamiento**, no reenviados ni transcodificados por una app de mensajería.

### Resultados Camera2 de diagnóstico
- API 34, FULL para IDs 0/1, exposición/ISO manual posibles, frontal fijo, sin RAW_SENSOR, sin EIS/OIS anunciados.
- Máximo JPEG Camera2 anunciado: trasera 3968×2976, frontal 3264×2448.
- Perfil 1080p30 anunciado y 1440p30 HIGH anunciado; video 4K no anunciado como perfil y requiere pruebas independientes. La cámara stock grabó más FPS en el archivo recibido, pero Camera2 reportó solo rangos AE hasta 30 FPS; no prometer 60 FPS en una cámara de terceros sin validación.

### Criterios de aceptación de nueva versión
1. No mostrar “GUARDADA” mientras `IS_PENDING` no se haya publicado.
2. Miniatura abre JPEG/MP4 correcto y permite identificar el último archivo guardado, aun si la generación de miniatura tarda.
3. Captura múltiple sucesiva, sin congelación visible por escrituras de disco.
4. Video finaliza sin congelar la interfaz ni produce MP4 inválidos.
5. JPEG nativo mantiene la resolución anunciada y mejora la experiencia de exposición en situaciones reales comparables.
6. Evaluar el audio CAMCORDER solicitado a 48 kHz/192 kbps mono; si la voz no mejora o falta audio, volver a MIC o diseñar grabación AudioRecord propia para procesado DSP.
7. Evaluar renderización natural y sin halos; no marcar como “IA” si no hay un modelo entrenado y comprobado.
