# LUXCAM PRO 3.0 BETA — Proyecto para GitHub Actions

**Estado:** Fuente preparada y verificada estáticamente. **NO** compilada ni instalada en Infinix en este entorno. Las mejoras en imagen y audio **requieren validación real** antes de llamarla definitiva.

## Estructura: respeta las rutas exactas

Repositorio: `https://github.com/puntoagilsa/LuxApp`, rama `main`. El código se mantiene en la subcarpeta `Camera2Diagnostico/`.

### Reemplazar
1. `Camera2Diagnostico/app/src/main/java/com/altoke/camera2diagnostico/LuxCamActivity.java` — actividad Camera2 completa.
2. `Camera2Diagnostico/app/src/main/AndroidManifest.xml` — nombre e icono de aplicación.
3. `Camera2Diagnostico/app/build.gradle` — número y nombre de versión.
4. `.github/workflows/compilar-apk.yml` — nombre del artefacto de la versión 3; mantiene la misma compilación Gradle que ya funcionó.

### Crear directorios y archivos
Los iconos `mipmap-mdpi` a `mipmap-xxxhdpi` en `Camera2Diagnostico/app/src/main/res/`; cada carpeta contiene `ic_launcher.png` e `ic_launcher_round.png`, derivados sin rediseñar del icono dorado compartido.

### NO tocar
`MainActivity.java` de diagnóstico, `Camera2Diagnostico/build.gradle`, `settings.gradle`, `gradle.properties`, gradle wrapper y archivos ajenos.

## Subir archivos sin Android Studio

1. **Opción robusta:** usa GitHub Desktop o Git local para copiar todas las carpetas del ZIP respetando rutas y hacer un solo commit. Si usas web de GitHub, edita 4 archivos y crea/sube 10 iconos por carpetas.
2. Si usas GitHub web, **no** subas la carpeta adicional `LuxCam_Pro_v3` ni un ZIP como archivo; los archivos deben quedar en sus rutas anteriores dentro del repositorio.
3. En la web, cualquier commit a `main` dispara GitHub Actions. Abre **solo la última ejecución**, la que incluye **todos** los archivos.
4. En `Actions` elige **Compilar APK LuxCam Pro**. Cuando esté verde, en `Artifacts` descarga `LuxCam-Pro-v3-APK`, descomprime y encontrarás `app-debug.apk`.
5. Si está rojo, abre el paso **Compilar APK** y comparte **error** y **What went wrong** sin modificar archivos a ciegas.
6. Esta versión usa `applicationId com.altoke.luxcampro` para instalarse en paralelo con LuxCam Fase 2 (`com.altoke.luxcam`), lo que permite comparar ambas sin desinstalar. Los APK de GitHub Actions firmados con claves **debug generadas de nuevo** pueden no permitir instalar actualizaciones sobre la versión anterior. Para una aplicación distribuible hay que configurar firma **release persistente** (keystore guardado como secreto) y no publicar claves privadas. Antes de quitar una versión, exporta cualquier configuración/dato local que necesites; fotos en MediaStore suelen permanecer.

## Funciones preparadas
- Visor Camera2, fotografía JPEG sin recomprimir, video H.264 solicitado 1080p30, AA audio AAC con fuente CAMCORDER solicitado a 48kHz mono y 192 kbps.
- Guardado JPEG en `Pictures/LuxCam`, video `Movies/LuxCam` usando `MediaStore.IS_PENDING`: mensaje Guardando/Finalizando y sólo confirmado tras publicar correctamente.
- Miniatura de último archivo guardado; pulsar para abrir foto o MP4 en la app compatible.
- Guardado JPEG en `ExecutorService` de un único hilo, liberando el buffer de Camera2 antes de tocar el almacenamiento.
- Finalización MP4 fuera del hilo de interfaz.
- Deslizador EV y Proteger luces; PRO desplegable con ISO/obturación en fotografía trasera, WB, flash auto, zoom digital, bloqueo AE, cuadrícula, cámara frontal.
- Icono dorado compartido, redimensionado sin alteraciones.

## Limitaciones explícitas
- HDR multicuadro real, RAW/DNG, EIS/OIS, 4K, IA local de denoise y 60fps Camera2 **no demostrados/soportados** por diagnóstico. No fingir que están implementados.
- Modo PRO manual establece tanto ISO como tiempo: si dejas uno en AUTO y modificas el otro, por compatibilidad se usará un valor predeterminado para el otro (ISO 200 o 1/100 s). No es verdadera prioridad ISO/velocidad bajo Android 14.
- No hay prueba de mejora de audio con el nuevo CAMCORDER/48kHz; sólo se configura el origen/tasa.
- No se debe prometer resultados idénticos a teléfonos de alta gama; el ISP propietario y las ópticas limitan el resultado.
- La confirmación de video puede demorar unos segundos para finalizar MP4. La UI **no** debe decir guardado antes de que finalice; no hay garantía de cero latencia.
- Al grabar por primera vez, compara 1080p y framerate de archivos **originales** locales: los videos compartidos llegaron a 720×1280. Verifica asimismo orientación, audio y reanudación de visor.

## Pruebas prioritarias
1. Tomar 4 fotos seguidas: confirmación aparece al finalizar cada guardado; la miniatura se carga después sin bloquear; pulsarla abre el JPEG y confirma resolución nativa.
2. Grabar 10 segundos hablando; detener; comprobar «FINALIZANDO…», luego «VIDEO GUARDADO» y reproducción al tocar miniatura.
3. Salir de la app durante grabación y verificar MP4 válido sin bloqueo al volver.
4. Cámara frontal/trasera, ISO manual (trasera), balance de blancos y zoom.
5. Controles de exposición EV 0, −0,3 y +0,3, con escenas idénticas y el mismo encuadre; verificar altas luces, piel, sombras.
6. Exterior y poca luz: escuchar ruido ambiental, distorsión y voz con archivos originales del teléfono, sin compresión por mensajería.
7. Si la compilación falla, no atribuir errores a otras versiones: compartir el registro exacto del job.

## Sobre licencias
El icono suministrado se incorpora únicamente como archivo del usuario; usarlo conforme a sus derechos sobre la imagen.
